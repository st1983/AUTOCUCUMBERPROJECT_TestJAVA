# Fix for Compilation Error - TestNG Version

## Problem

```
[ERROR] class file has wrong version 55.0, should be 52.0
```

This error occurs because:
- **TestNG 7.8.0** requires **Java 11** (class file version 55.0)
- Your project is configured for **Java 8** (class file version 52.0)

## Solution

Updated `pom.xml` to use **TestNG 6.14.3**, which is compatible with Java 8.

### Change Made

```xml
<!-- Before (Java 11+ only) -->
<testng.version>7.8.0</testng.version>

<!-- After (Java 8 compatible) -->
<testng.version>6.14.3</testng.version>
```

## Verification

Run the following to verify the fix:

```bash
mvn clean compile
```

## TestNG Version Compatibility

| TestNG Version | Java Version | Class File Version |
|----------------|--------------|-------------------|
| 6.14.3 | Java 8+ | 52.0 |
| 7.0.0+ | Java 11+ | 55.0 |

## Note

TestNG 6.14.3 is the last version that supports Java 8. All features work the same, just with Java 8 compatibility.

## If You Still Have Issues

1. **Clean Maven cache**:
   ```bash
   mvn dependency:purge-local-repository
   ```

2. **Delete old TestNG from local repository**:
   ```bash
   # Windows
   rmdir /s C:\Users\LENOVO\.m2\repository\org\testng\testng\7.8.0
   
   # Linux/Mac
   rm -rf ~/.m2/repository/org/testng/testng/7.8.0
   ```

3. **Recompile**:
   ```bash
   mvn clean compile
   ```

---

**The fix has been applied. Try compiling again!**

