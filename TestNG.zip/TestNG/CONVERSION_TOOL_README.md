# TestNG to Cucumber Conversion Tool

This tool automates the conversion of Selenium Java TestNG Page Object Model framework to Cucumber Java Page Object Model format.

## Overview

The conversion tool analyzes your existing TestNG test classes and automatically generates:
- **Feature files** (.feature) in Gherkin format
- **Step definitions** (.java) with Cucumber annotations
- **Hooks class** for setup/teardown (converted from @BeforeMethod/@AfterMethod)

## Components

### 1. TestNGTestParser
Parses TestNG test classes to extract:
- Test methods (@Test)
- Setup/teardown methods (@BeforeMethod, @AfterMethod, @BeforeClass, @AfterClass)
- Method bodies and logic
- Page objects used
- Assertions

### 2. FeatureFileGenerator
Generates Cucumber feature files (.feature) with:
- Feature descriptions
- Scenarios from test methods
- Tags from TestNG groups
- Background steps (from @BeforeMethod)

### 3. StepDefinitionGenerator
Generates step definition classes with:
- Cucumber annotations (@Given, @When, @Then, @And)
- Page object initialization
- Method implementations based on test logic

### 4. HooksGenerator
Generates Hooks class with:
- @Before hook (from @BeforeMethod)
- @After hook (from @AfterMethod)
- Screenshot capture on failure

## Usage

### Method 1: Using Command Line Arguments

```bash
# Compile the converter
mvn compile

# Run the converter
java -cp target/classes com.automation.converter.TestNGToCucumberConverter \
    <testng-source-dir> <cucumber-output-dir> [package-name]

# Example:
java -cp target/classes com.automation.converter.TestNGToCucumberConverter \
    src/test/java/com/example/tests \
    target/cucumber-output \
    com.example.stepdefinitions
```

### Method 2: Using Configuration File

1. Edit `src/main/resources/converter-config.properties`:
```properties
testng.source.directory=src/test/java/com/automation/tests
cucumber.output.directory=target/cucumber-output
cucumber.package.name=com.automation.stepdefinitions
```

2. Run the converter:
```bash
java -cp target/classes com.automation.converter.TestNGToCucumberConverter \
    src/main/resources/converter-config.properties
```

### Method 3: Using Maven Exec Plugin

Add to `pom.xml`:
```xml
<plugin>
    <groupId>org.codehaus.mojo</groupId>
    <artifactId>exec-maven-plugin</artifactId>
    <version>3.1.0</version>
    <configuration>
        <mainClass>com.automation.converter.TestNGToCucumberConverter</mainClass>
        <arguments>
            <argument>src/test/java/com/automation/tests</argument>
            <argument>target/cucumber-output</argument>
            <argument>com.automation.stepdefinitions</argument>
        </arguments>
    </configuration>
</plugin>
```

Then run:
```bash
mvn exec:java
```

## Example Conversion

### Input: TestNG Test Class

```java
package com.example.tests;

import org.testng.annotations.*;
import com.example.pages.LoginPage;
import com.example.pages.HomePage;
import org.testng.Assert;

public class LoginTest {
    
    @BeforeMethod
    public void setUp() {
        DriverManager.initializeDriver();
    }
    
    @Test(description = "Successful login with valid credentials", groups = {"smoke"})
    public void testLoginWithValidCredentials() {
        LoginPage loginPage = new LoginPage();
        loginPage.navigateTo("https://example.com/login");
        loginPage.login("username", "password");
        HomePage homePage = new HomePage();
        Assert.assertTrue(homePage.isUserLoggedIn());
    }
    
    @AfterMethod
    public void tearDown() {
        DriverManager.quitDriver();
    }
}
```

### Output: Generated Feature File

```gherkin
@login
Feature: Login
  As a user
  I want to test login functionality
  So that I can verify the application works correctly

  Background:
    Given the test environment is set up

  @smoke
  Scenario: Successful login with valid credentials
    Given I am on the login page
    When I login with username "username" and password "password"
    Then I should see the expected result
```

### Output: Generated Step Definitions

```java
package com.automation.stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import com.automation.pages.LoginPage;
import com.automation.pages.HomePage;
import org.junit.Assert;

public class LoginStepDefinitions {
    private LoginPage loginPage;
    private HomePage homePage;

    public LoginStepDefinitions() {
        this.loginPage = new LoginPage();
        this.homePage = new HomePage();
    }

    @Given("I am on the login page")
    public void i_am_on_the_login_page() {
        loginPage.navigateTo("https://example.com/login");
    }

    @When("I login with username {string} and password {string}")
    public void i_login_with_username_and_password(String username, String password) {
        loginPage.login(username, password);
    }

    @Then("I should see the expected result")
    public void i_should_see_the_expected_result() {
        Assert.assertTrue(homePage.isUserLoggedIn());
    }
}
```

### Output: Generated Hooks

```java
package com.automation.stepdefinitions;

import com.automation.utils.DriverManager;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class Hooks {
    @Before
    public void setUp(Scenario scenario) {
        System.out.println("Starting scenario: " + scenario.getName());
        DriverManager.initializeDriver();
    }

    @After
    public void tearDown(Scenario scenario) {
        if (scenario.isFailed()) {
            byte[] screenshot = ((TakesScreenshot) DriverManager.getDriver())
                    .getScreenshotAs(OutputType.BYTES);
            scenario.attach(screenshot, "image/png", "Screenshot");
        }
        System.out.println("Ending scenario: " + scenario.getName());
        DriverManager.quitDriver();
    }
}
```

## Post-Conversion Steps

After running the converter:

1. **Review Generated Files**: The tool generates basic structure, but you may need to:
   - Refine step definitions to match your exact needs
   - Update feature file scenarios with better descriptions
   - Customize hooks based on your setup/teardown requirements

2. **Update Page Objects**: Ensure your page objects are compatible:
   - Page objects should extend `BasePage`
   - Methods should be accessible from step definitions

3. **Test the Conversion**: 
   ```bash
   mvn test
   ```

4. **Refine Steps**: The generated steps are templates. You may need to:
   - Add parameterization
   - Improve step descriptions
   - Add data tables or scenario outlines where appropriate

## Limitations

The conversion tool uses pattern matching and heuristics, so:

- **Complex logic** may require manual refinement
- **Data providers** need to be converted to Scenario Outlines manually
- **Test dependencies** need to be handled manually
- **Custom annotations** may not be converted automatically

## Customization

You can extend the tool by:

1. **Enhancing Pattern Matching**: Update regex patterns in `TestNGTestParser` to match your coding patterns
2. **Improving Step Generation**: Modify `FeatureFileGenerator` to generate more specific steps
3. **Adding Custom Logic**: Extend generators to handle specific patterns in your codebase

## Troubleshooting

### No test classes found
- Verify the source directory path is correct
- Ensure test files end with `Test.java` or `Tests.java`
- Check that files contain `@Test` annotations

### Generated steps are too generic
- The tool generates basic steps; refine them manually
- Add more specific pattern matching in the generators
- Enhance method body analysis

### Compilation errors in generated code
- Check package names match your project structure
- Verify page object imports are correct
- Ensure all dependencies are in `pom.xml`

## Support

For issues or enhancements, review the generated code and customize as needed. The tool provides a starting point for conversion, but manual refinement is expected for production use.

