package com.automation.stepdefinitions;

import com.automation.utils.DriverManager;
import com.automation.utils.ExtentReportManager;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import java.util.Base64;

/**
 * Hooks class - Similar to @BeforeMethod and @AfterMethod in TestNG
 * Handles setup and teardown for each scenario
 * Integrated with Extent Reports
 */
public class Hooks {

    @Before
    public void setUp(Scenario scenario) {
        System.out.println("Starting scenario: " + scenario.getName());
        
        // Initialize Extent Test for this scenario
        ExtentReportManager.createTest(
            scenario.getName(),
            scenario.getUri().toString()
        );
        ExtentReportManager.logInfo("Browser: " + com.automation.utils.ConfigReader.getProperty("browser", "Chrome"));
        
        // Initialize WebDriver
        DriverManager.initializeDriver();
        ExtentReportManager.logInfo("WebDriver initialized");
    }

    @After
    public void tearDown(Scenario scenario) {
        if (scenario.isFailed()) {
            // Take screenshot on failure
            try {
                byte[] screenshot = ((TakesScreenshot) DriverManager.getDriver())
                        .getScreenshotAs(OutputType.BYTES);
                String base64Screenshot = Base64.getEncoder().encodeToString(screenshot);
                
                // Attach to Cucumber report
                scenario.attach(screenshot, "image/png", "Screenshot");
                
                // Attach to Extent Report
                ExtentReportManager.addScreenshot(base64Screenshot, "Failure Screenshot");
                ExtentReportManager.logFail("Scenario failed: " + scenario.getName());
                
                // Log error details if available
                if (scenario.getSourceTagNames() != null) {
                    ExtentReportManager.logInfo("Tags: " + scenario.getSourceTagNames().toString());
                }
            } catch (Exception e) {
                ExtentReportManager.logWarning("Failed to capture screenshot: " + e.getMessage());
            }
        } else {
            ExtentReportManager.logPass("Scenario passed: " + scenario.getName());
        }
        
        System.out.println("Ending scenario: " + scenario.getName() + " - Status: " + 
            (scenario.isFailed() ? "FAILED" : "PASSED"));
        
        // Quit WebDriver
        DriverManager.quitDriver();
        ExtentReportManager.logInfo("WebDriver closed");
        
        // Remove test from thread local
        ExtentReportManager.removeTest(Thread.currentThread().getName());
    }
}

