package com.automation.stepdefinitions;

import com.automation.pages.HomePage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import org.junit.Assert;

/**
 * HomePageStepDefinitions - Step definitions for Home page feature
 */
public class HomePageStepDefinitions {

    private HomePage homePage;

    public HomePageStepDefinitions() {
        this.homePage = new HomePage();
    }

    @Given("I am logged in to the application")
    public void i_am_logged_in_to_the_application() {
        // Navigate to home page (assuming user is already logged in)
        homePage.navigateTo("https://example.com/home");
    }

    @When("I click on the logout link")
    public void i_click_on_the_logout_link() {
        homePage.clickLogout();
    }

    @Then("I should be logged out")
    public void i_should_be_logged_out() {
        // Verify user is logged out - adjust based on your application
        Assert.assertFalse("User should be logged out", homePage.isUserLoggedIn());
    }

    @When("I click on the dashboard link")
    public void i_click_on_the_dashboard_link() {
        homePage.clickDashboard();
    }

    @Then("I should be on the dashboard page")
    public void i_should_be_on_the_dashboard_page() {
        String currentUrl = homePage.getCurrentUrl();
        Assert.assertTrue("Should be on dashboard page", currentUrl.contains("dashboard"));
    }
}

