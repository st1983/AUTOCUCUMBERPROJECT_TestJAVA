package com.automation.stepdefinitions;

import com.automation.pages.HomePage;
import com.automation.pages.LoginPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.And;
import org.junit.Assert;

/**
 * LoginStepDefinitions - Step definitions for Login feature
 * This replaces TestNG test methods with Cucumber step definitions
 */
public class LoginStepDefinitions {

    private LoginPage loginPage;
    private HomePage homePage;

    public LoginStepDefinitions() {
        this.loginPage = new LoginPage();
        this.homePage = new HomePage();
    }

    @Given("I am on the login page")
    public void i_am_on_the_login_page() {
        loginPage.navigateTo("https://example.com/login");
    }

    @When("I enter username {string} and password {string}")
    public void i_enter_username_and_password(String username, String password) {
        loginPage.enterUsername(username);
        loginPage.enterPassword(password);
    }

    @And("I click on the login button")
    public void i_click_on_the_login_button() {
        loginPage.clickLoginButton();
    }

    @When("I login with username {string} and password {string}")
    public void i_login_with_username_and_password(String username, String password) {
        loginPage.login(username, password);
    }

    @Then("I should be redirected to the home page")
    public void i_should_be_redirected_to_the_home_page() {
        Assert.assertTrue("User should be logged in", homePage.isUserLoggedIn());
    }

    @Then("I should see an error message")
    public void i_should_see_an_error_message() {
        Assert.assertTrue("Error message should be displayed", loginPage.isErrorMessageDisplayed());
    }

    @Then("I should see the error message {string}")
    public void i_should_see_the_error_message(String expectedErrorMessage) {
        String actualErrorMessage = loginPage.getErrorMessage();
        Assert.assertEquals("Error message should match", expectedErrorMessage, actualErrorMessage);
    }

    @Then("I should see a welcome message")
    public void i_should_see_a_welcome_message() {
        Assert.assertTrue("Welcome message should be displayed", homePage.isWelcomeMessageDisplayed());
    }

    @And("I should see the welcome message {string}")
    public void i_should_see_the_welcome_message(String expectedMessage) {
        String actualMessage = homePage.getWelcomeMessage();
        Assert.assertEquals("Welcome message should match", expectedMessage, actualMessage);
    }
}

