package com.automation.runners;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

/**
 * TestRunner - Main test runner class
 * This replaces TestNG test classes and XML suites
 * 
 * To run specific features or tags, modify the tags option
 * Example: tags = "@smoke" or tags = "@regression"
 */
@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/resources/features",
        glue = {"com.automation.stepdefinitions", "com.automation.hooks"},
        plugin = {
                "pretty",
                "html:target/cucumber-reports/cucumber.html",
                "json:target/cucumber-reports/cucumber.json",
                "junit:target/cucumber-reports/cucumber.xml"
        },
        monochrome = true,
        dryRun = false,
        tags = "@smoke or @regression"
)
public class TestRunner {
    // This class is used by JUnit to run Cucumber tests
    // No code needed here
}

