package com.automation.tests.example;

import com.automation.pages.HomePage;
import com.automation.pages.LoginPage;
import com.automation.utils.DriverManager;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * ExampleLoginTest - Example TestNG test class for conversion demonstration
 * This class demonstrates a typical TestNG test that can be converted to Cucumber
 */
public class ExampleLoginTest {
    
    @BeforeMethod
    public void setUp() {
        DriverManager.initializeDriver();
    }
    
    @Test(description = "Successful login with valid credentials", groups = {"smoke", "login"})
    public void testLoginWithValidCredentials() {
        LoginPage loginPage = new LoginPage();
        loginPage.navigateTo("https://example.com/login");
        loginPage.login("validuser", "validpass");
        HomePage homePage = new HomePage();
        Assert.assertTrue(homePage.isUserLoggedIn(), "User should be logged in");
    }
    
    @Test(description = "Failed login with invalid credentials", groups = {"regression", "login"})
    public void testLoginWithInvalidCredentials() {
        LoginPage loginPage = new LoginPage();
        loginPage.navigateTo("https://example.com/login");
        loginPage.enterUsername("invaliduser");
        loginPage.enterPassword("invalidpass");
        loginPage.clickLoginButton();
        Assert.assertTrue(loginPage.isErrorMessageDisplayed(), "Error message should be displayed");
    }
    
    @AfterMethod
    public void tearDown() {
        DriverManager.quitDriver();
    }
}

