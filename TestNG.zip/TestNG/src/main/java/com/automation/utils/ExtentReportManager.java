package com.automation.utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * ExtentReportManager - Manages Extent Reports for Cucumber tests
 * Provides thread-safe report management
 */
public class ExtentReportManager {
    
    private static ExtentReports extentReports;
    private static Map<String, ExtentTest> extentTestMap = new HashMap<>();
    public static final ThreadLocal<ExtentTest> extentTest = new ThreadLocal<>();
    
    private static final String REPORT_DIRECTORY = "test-output/ExtentReports/";
    private static final String REPORT_NAME = "ExtentReport_";

    /**
     * Initialize Extent Reports
     */
    public static ExtentReports getExtentReports() {
        if (extentReports == null) {
            extentReports = createExtentReports();
        }
        return extentReports;
    }

    private static ExtentReports createExtentReports() {
        // Create report directory if it doesn't exist
        File reportDir = new File(REPORT_DIRECTORY);
        if (!reportDir.exists()) {
            reportDir.mkdirs();
        }

        // Generate report file name with timestamp
        String timestamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date());
        String reportFileName = REPORT_NAME + timestamp + ".html";
        String reportPath = REPORT_DIRECTORY + reportFileName;

        // Create ExtentHtmlReporter (Java 8 compatible)
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(reportPath);
        
        // Configure report
        htmlReporter.config().setDocumentTitle("Cucumber Test Execution Report");
        htmlReporter.config().setReportName("Automation Test Report");
        htmlReporter.config().setTheme(Theme.STANDARD);
        
        // Create ExtentReports instance
        ExtentReports extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
        
        // Set system information
        extent.setSystemInfo("OS", System.getProperty("os.name"));
        extent.setSystemInfo("OS Version", System.getProperty("os.version"));
        extent.setSystemInfo("Java Version", System.getProperty("java.version"));
        extent.setSystemInfo("User Name", System.getProperty("user.name"));
        extent.setSystemInfo("Browser", ConfigReader.getProperty("browser", "Chrome"));
        
        return extent;
    }

    /**
     * Create test in Extent Report
     */
    public static ExtentTest createTest(String testName, String description) {
        ExtentTest test = getExtentReports().createTest(testName, description);
        extentTest.set(test);
        extentTestMap.put(Thread.currentThread().getName(), test);
        return test;
    }

    /**
     * Create test in Extent Report
     */
    public static ExtentTest createTest(String testName) {
        return createTest(testName, "");
    }

    /**
     * Get current test
     */
    public static ExtentTest getTest() {
        return extentTest.get();
    }

    /**
     * Get test by thread name
     */
    public static ExtentTest getTest(String threadName) {
        return extentTestMap.get(threadName);
    }

    /**
     * Log info message
     */
    public static void logInfo(String message) {
        ExtentTest test = getTest();
        if (test != null) {
            test.info(message);
        }
    }

    /**
     * Log pass message
     */
    public static void logPass(String message) {
        ExtentTest test = getTest();
        if (test != null) {
            test.pass(message);
        }
    }

    /**
     * Log fail message
     */
    public static void logFail(String message) {
        ExtentTest test = getTest();
        if (test != null) {
            test.fail(message);
        }
    }

    /**
     * Log skip message
     */
    public static void logSkip(String message) {
        ExtentTest test = getTest();
        if (test != null) {
            test.skip(message);
        }
    }

    /**
     * Log warning message
     */
    public static void logWarning(String message) {
        ExtentTest test = getTest();
        if (test != null) {
            test.warning(message);
        }
    }

    /**
     * Add screenshot to report
     */
    public static void addScreenshot(String base64Screenshot, String title) {
        ExtentTest test = getTest();
        if (test != null) {
            test.addScreenCaptureFromBase64String(base64Screenshot, title);
        }
    }

    /**
     * Add screenshot to report
     */
    public static void addScreenshot(String screenshotPath) {
        ExtentTest test = getTest();
        if (test != null) {
            try {
                test.addScreenCaptureFromPath(screenshotPath);
            } catch (Exception e) {
                test.warning("Failed to add screenshot: " + e.getMessage());
            }
        }
    }

    /**
     * Flush report
     */
    public static void flushReport() {
        if (extentReports != null) {
            extentReports.flush();
        }
    }

    /**
     * Remove test from map
     */
    public static void removeTest(String threadName) {
        extentTestMap.remove(threadName);
        extentTest.remove();
    }
}

