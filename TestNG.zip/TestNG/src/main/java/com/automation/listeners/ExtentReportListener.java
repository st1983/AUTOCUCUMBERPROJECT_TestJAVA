package com.automation.listeners;

import com.automation.utils.ExtentReportManager;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import io.cucumber.plugin.EventListener;
import io.cucumber.plugin.event.*;

import java.util.HashMap;
import java.util.Map;

/**
 * ExtentReportListener - Cucumber plugin for Extent Reports integration
 * Handles Cucumber events and updates Extent Reports accordingly
 */
public class ExtentReportListener implements EventListener {

    private static Map<String, ExtentTest> featureTestMap = new HashMap<>();
    private static Map<String, ExtentTest> scenarioTestMap = new HashMap<>();

    @Override
    public void setEventPublisher(EventPublisher publisher) {
        publisher.registerHandlerFor(TestRunStarted.class, this::handleTestRunStarted);
        publisher.registerHandlerFor(TestRunFinished.class, this::handleTestRunFinished);
        publisher.registerHandlerFor(TestCaseStarted.class, this::handleTestCaseStarted);
        publisher.registerHandlerFor(TestCaseFinished.class, this::handleTestCaseFinished);
        publisher.registerHandlerFor(TestStepStarted.class, this::handleTestStepStarted);
        publisher.registerHandlerFor(TestStepFinished.class, this::handleTestStepFinished);
    }

    private void handleTestRunStarted(TestRunStarted event) {
        ExtentReportManager.getExtentReports();
    }

    private void handleTestRunFinished(TestRunFinished event) {
        ExtentReportManager.flushReport();
    }

    private void handleTestCaseStarted(TestCaseStarted event) {
        String scenarioName = event.getTestCase().getName();
        String featureName = event.getTestCase().getUri().toString();
        
        // Get or create feature test
        ExtentTest featureTest = featureTestMap.get(featureName);
        if (featureTest == null) {
            featureTest = ExtentReportManager.getExtentReports()
                    .createTest(featureName);
            featureTestMap.put(featureName, featureTest);
        }
        
        // Create scenario test
        ExtentTest scenarioTest = featureTest.createNode(scenarioName);
        scenarioTestMap.put(scenarioName, scenarioTest);
        ExtentReportManager.extentTest.set(scenarioTest);
        
        // Log scenario start
        ExtentReportManager.logInfo("Scenario: " + scenarioName + " started");
    }

    private void handleTestCaseFinished(TestCaseFinished event) {
        String scenarioName = event.getTestCase().getName();
        ExtentTest scenarioTest = scenarioTestMap.get(scenarioName);
        
        if (scenarioTest != null) {
            Result result = event.getResult();
            Status status = mapCucumberStatusToExtentStatus(result.getStatus());
            
            if (status == Status.FAIL) {
                scenarioTest.fail("Test failed: " + result.getError().getMessage());
                if (result.getError() != null) {
                    scenarioTest.fail(result.getError());
                }
            } else if (status == Status.SKIP) {
                scenarioTest.skip("Test skipped");
            } else {
                scenarioTest.pass("Test passed");
            }
        }
    }

    private void handleTestStepStarted(TestStepStarted event) {
        String stepName = event.getTestStep().toString();
        ExtentReportManager.logInfo("Step: " + stepName);
    }

    private void handleTestStepFinished(TestStepFinished event) {
        Result result = event.getResult();
        Status status = mapCucumberStatusToExtentStatus(result.getStatus());
        
        if (status == Status.FAIL) {
            ExtentReportManager.logFail("Step failed: " + result.getError().getMessage());
            if (result.getError() != null) {
                ExtentReportManager.getTest().fail(result.getError());
            }
        } else if (status == Status.SKIP) {
            ExtentReportManager.logSkip("Step skipped");
        } else {
            ExtentReportManager.logPass("Step passed");
        }
    }

    private Status mapCucumberStatusToExtentStatus(io.cucumber.plugin.event.Status cucumberStatus) {
        switch (cucumberStatus) {
            case PASSED:
                return Status.PASS;
            case FAILED:
                return Status.FAIL;
            case SKIPPED:
                return Status.SKIP;
            default:
                return Status.INFO;
        }
    }
}

