package com.automation.pages;

import com.automation.utils.DriverManager;
import com.automation.utils.Helper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

/**
 * BasePage class - All page objects should extend this class
 * This follows the Page Object Model pattern
 */
public class BasePage {
    protected WebDriver driver;
    protected Helper helper;

    public BasePage() {
        this.driver = DriverManager.getDriver();
        this.helper = new Helper(driver);
        PageFactory.initElements(driver, this);
    }

    public String getPageTitle() {
        return driver.getTitle();
    }

    public String getCurrentUrl() {
        return driver.getCurrentUrl();
    }

    public void navigateTo(String url) {
        driver.get(url);
    }
}

