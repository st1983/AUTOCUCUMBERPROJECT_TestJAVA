package com.automation.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * HomePage - Page Object for Home page functionality
 */
public class HomePage extends BasePage {

    @FindBy(className = "welcome-message")
    private WebElement welcomeMessage;

    @FindBy(linkText = "Logout")
    private WebElement logoutLink;

    @FindBy(linkText = "Dashboard")
    private WebElement dashboardLink;

    public String getWelcomeMessage() {
        return helper.getText(welcomeMessage);
    }

    public boolean isWelcomeMessageDisplayed() {
        return helper.isDisplayed(welcomeMessage);
    }

    public void clickLogout() {
        helper.click(logoutLink);
    }

    public void clickDashboard() {
        helper.click(dashboardLink);
    }

    public boolean isUserLoggedIn() {
        return helper.isDisplayed(welcomeMessage);
    }
}

