package com.automation.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * LoginPage - Page Object for Login functionality
 * Example page object that can be used in Cucumber step definitions
 */
public class LoginPage extends BasePage {

    @FindBy(id = "username")
    private WebElement usernameField;

    @FindBy(id = "password")
    private WebElement passwordField;

    @FindBy(id = "login-button")
    private WebElement loginButton;

    @FindBy(className = "error-message")
    private WebElement errorMessage;

    @FindBy(className = "success-message")
    private WebElement successMessage;

    public void enterUsername(String username) {
        helper.sendKeys(usernameField, username);
    }

    public void enterPassword(String password) {
        helper.sendKeys(passwordField, password);
    }

    public void clickLoginButton() {
        helper.click(loginButton);
    }

    public void login(String username, String password) {
        enterUsername(username);
        enterPassword(password);
        clickLoginButton();
    }

    public boolean isErrorMessageDisplayed() {
        return helper.isDisplayed(errorMessage);
    }

    public String getErrorMessage() {
        return helper.getText(errorMessage);
    }

    public boolean isSuccessMessageDisplayed() {
        return helper.isDisplayed(successMessage);
    }

    public String getSuccessMessage() {
        return helper.getText(successMessage);
    }
}

