package com.automation.integration;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.apache.http.HttpHeaders;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/**
 * JiraTestCaseFetcher - Fetches test cases from Jira using REST API
 * Supports Jira Cloud and Jira Server
 */
public class JiraTestCaseFetcher {
    
    private String jiraUrl;
    private String username;
    private String apiToken;
    private CloseableHttpClient httpClient;
    private Gson gson;
    
    public JiraTestCaseFetcher(String jiraUrl, String username, String apiToken) {
        this.jiraUrl = jiraUrl.endsWith("/") ? jiraUrl : jiraUrl + "/";
        this.username = username;
        this.apiToken = apiToken;
        this.httpClient = HttpClients.createDefault();
        this.gson = new Gson();
    }
    
    /**
     * Fetch test cases from a Jira project
     */
    public List<JiraTestCase> fetchTestCasesFromProject(String projectKey) throws IOException {
        List<JiraTestCase> testCases = new ArrayList<>();
        int startAt = 0;
        int maxResults = 50;
        boolean hasMore = true;
        
        while (hasMore) {
            String jql = String.format("project = %s AND type = Test", projectKey);
            String url = jiraUrl + "rest/api/2/search?jql=" + 
                        java.net.URLEncoder.encode(jql, StandardCharsets.UTF_8.toString()) +
                        "&startAt=" + startAt + "&maxResults=" + maxResults;
            
            JsonObject response = executeGetRequest(url);
            JsonArray issues = response.getAsJsonArray("issues");
            
            for (int i = 0; i < issues.size(); i++) {
                JsonObject issue = issues.get(i).getAsJsonObject();
                JiraTestCase testCase = parseTestCase(issue);
                testCases.add(testCase);
            }
            
            startAt += maxResults;
            hasMore = response.get("total").getAsInt() > startAt;
        }
        
        return testCases;
    }
    
    /**
     * Fetch test cases from a Jira filter
     */
    public List<JiraTestCase> fetchTestCasesFromFilter(String filterId) throws IOException {
        String url = jiraUrl + "rest/api/2/filter/" + filterId;
        
        JsonObject filter = executeGetRequest(url);
        String jql = filter.get("jql").getAsString();
        
        return fetchTestCasesByJQL(jql);
    }
    
    /**
     * Fetch test cases using JQL query
     */
    public List<JiraTestCase> fetchTestCasesByJQL(String jql) throws IOException {
        List<JiraTestCase> testCases = new ArrayList<>();
        int startAt = 0;
        int maxResults = 50;
        boolean hasMore = true;
        
        while (hasMore) {
            String url = jiraUrl + "rest/api/2/search?jql=" + 
                        java.net.URLEncoder.encode(jql, StandardCharsets.UTF_8.toString()) +
                        "&startAt=" + startAt + "&maxResults=" + maxResults;
            
            JsonObject response = executeGetRequest(url);
            JsonArray issues = response.getAsJsonArray("issues");
            
            for (int i = 0; i < issues.size(); i++) {
                JsonObject issue = issues.get(i).getAsJsonObject();
                JiraTestCase testCase = parseTestCase(issue);
                testCases.add(testCase);
            }
            
            startAt += maxResults;
            hasMore = response.get("total").getAsInt() > startAt;
        }
        
        return testCases;
    }
    
    /**
     * Fetch a single test case by key
     */
    public JiraTestCase fetchTestCaseByKey(String issueKey) throws IOException {
        String url = jiraUrl + "rest/api/2/issue/" + issueKey;
        JsonObject issue = executeGetRequest(url);
        return parseTestCase(issue);
    }
    
    private JsonObject executeGetRequest(String url) throws IOException {
        HttpGet request = new HttpGet(url);
        
        // Set authentication header
        String auth = username + ":" + apiToken;
        String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes(StandardCharsets.UTF_8));
        request.setHeader(HttpHeaders.AUTHORIZATION, "Basic " + encodedAuth);
        request.setHeader(HttpHeaders.ACCEPT, "application/json");
        request.setHeader(HttpHeaders.CONTENT_TYPE, "application/json");
        
        try (CloseableHttpResponse response = httpClient.execute(request)) {
            String responseBody = EntityUtils.toString(response.getEntity());
            
            if (response.getStatusLine().getStatusCode() != 200) {
                throw new IOException("Jira API request failed: " + response.getStatusLine().getStatusCode() + 
                                    " - " + responseBody);
            }
            
            return gson.fromJson(responseBody, JsonObject.class);
        }
    }
    
    private JiraTestCase parseTestCase(JsonObject issue) {
        JiraTestCase testCase = new JiraTestCase();
        
        // Basic fields
        testCase.setKey(issue.get("key").getAsString());
        JsonObject fields = issue.getAsJsonObject("fields");
        
        testCase.setSummary(fields.has("summary") ? fields.get("summary").getAsString() : "");
        testCase.setDescription(fields.has("description") ? fields.get("description").getAsString() : "");
        testCase.setTestType(fields.has("customfield_10000") ? fields.get("customfield_10000").getAsString() : "");
        
        // Parse labels as tags
        if (fields.has("labels")) {
            JsonArray labels = fields.getAsJsonArray("labels");
            List<String> tags = new ArrayList<>();
            for (int i = 0; i < labels.size(); i++) {
                tags.add(labels.get(i).getAsString());
            }
            testCase.setTags(tags);
        }
        
        // Parse test steps (if available in custom fields)
        if (fields.has("customfield_10001")) {
            String testSteps = fields.get("customfield_10001").getAsString();
            testCase.setTestSteps(parseTestSteps(testSteps));
        } else if (fields.has("description")) {
            // Try to parse steps from description
            testCase.setTestSteps(parseTestStepsFromDescription(fields.get("description").getAsString()));
        }
        
        // Parse priority
        if (fields.has("priority")) {
            JsonObject priority = fields.getAsJsonObject("priority");
            testCase.setPriority(priority.get("name").getAsString());
        }
        
        return testCase;
    }
    
    private List<String> parseTestSteps(String testSteps) {
        List<String> steps = new ArrayList<>();
        if (testSteps == null || testSteps.isEmpty()) {
            return steps;
        }
        
        // Parse steps from formatted text (e.g., numbered list, bullet points)
        String[] lines = testSteps.split("\n");
        for (String line : lines) {
            line = line.trim();
            if (line.startsWith("1.") || line.startsWith("-") || line.startsWith("*")) {
                steps.add(line.replaceFirst("^[0-9]+\\.|^[-*]\\s*", "").trim());
            } else if (!line.isEmpty()) {
                steps.add(line);
            }
        }
        
        return steps;
    }
    
    private List<String> parseTestStepsFromDescription(String description) {
        List<String> steps = new ArrayList<>();
        if (description == null || description.isEmpty()) {
            return steps;
        }
        
        // Try to extract Gherkin-like steps from description
        String[] lines = description.split("\n");
        for (String line : lines) {
            line = line.trim();
            if (line.matches("(?i)^(Given|When|Then|And|But).*")) {
                steps.add(line);
            }
        }
        
        return steps;
    }
    
    public void close() throws IOException {
        if (httpClient != null) {
            httpClient.close();
        }
    }
}

