package com.automation.integration;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.apache.http.HttpHeaders;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/**
 * AzureDevOpsTestCaseFetcher - Fetches test cases from Azure DevOps using REST API
 */
public class AzureDevOpsTestCaseFetcher {
    
    private String organization;
    private String project;
    private String personalAccessToken;
    private CloseableHttpClient httpClient;
    private Gson gson;
    
    public AzureDevOpsTestCaseFetcher(String organization, String project, String personalAccessToken) {
        this.organization = organization;
        this.project = project;
        this.personalAccessToken = personalAccessToken;
        this.httpClient = HttpClients.createDefault();
        this.gson = new Gson();
    }
    
    /**
     * Fetch test cases from Azure DevOps test plan
     */
    public List<AzureDevOpsTestCase> fetchTestCasesFromTestPlan(int testPlanId) throws IOException {
        List<AzureDevOpsTestCase> testCases = new ArrayList<>();
        String url = String.format(
            "https://dev.azure.com/%s/%s/_apis/test/plans/%d/suites?api-version=6.0",
            organization, project, testPlanId
        );
        
        JsonObject response = executeGetRequest(url);
        JsonArray suites = response.getAsJsonArray("value");
        
        for (int i = 0; i < suites.size(); i++) {
            JsonObject suite = suites.get(i).getAsJsonObject();
            int suiteId = suite.get("id").getAsInt();
            List<AzureDevOpsTestCase> suiteTestCases = fetchTestCasesFromSuite(testPlanId, suiteId);
            testCases.addAll(suiteTestCases);
        }
        
        return testCases;
    }
    
    /**
     * Fetch test cases from a test suite
     */
    public List<AzureDevOpsTestCase> fetchTestCasesFromSuite(int testPlanId, int suiteId) throws IOException {
        List<AzureDevOpsTestCase> testCases = new ArrayList<>();
        String url = String.format(
            "https://dev.azure.com/%s/%s/_apis/test/plans/%d/suites/%d/testcases?api-version=6.0",
            organization, project, testPlanId, suiteId
        );
        
        JsonObject response = executeGetRequest(url);
        JsonArray testCaseRefs = response.getAsJsonArray("value");
        
        for (int i = 0; i < testCaseRefs.size(); i++) {
            JsonObject testCaseRef = testCaseRefs.get(i).getAsJsonObject();
            int workItemId = testCaseRef.getAsJsonObject("workItem").get("id").getAsInt();
            AzureDevOpsTestCase testCase = fetchTestCaseById(workItemId);
            testCases.add(testCase);
        }
        
        return testCases;
    }
    
    /**
     * Fetch test case by work item ID
     */
    public AzureDevOpsTestCase fetchTestCaseById(int workItemId) throws IOException {
        String url = String.format(
            "https://dev.azure.com/%s/%s/_apis/wit/workitems/%d?api-version=6.0",
            organization, project, workItemId
        );
        
        JsonObject workItem = executeGetRequest(url);
        return parseTestCase(workItem);
    }
    
    /**
     * Fetch test cases using WIQL (Work Item Query Language)
     */
    public List<AzureDevOpsTestCase> fetchTestCasesByQuery(String wiql) throws IOException {
        List<AzureDevOpsTestCase> testCases = new ArrayList<>();
        
        // Note: WIQL query execution requires POST request
        // For full implementation, use HttpPost with JSON body containing the WIQL query
        // This is a placeholder for future implementation
        
        return testCases;
    }
    
    private JsonObject executeGetRequest(String url) throws IOException {
        HttpGet request = new HttpGet(url);
        
        // Set authentication header (Basic auth with PAT)
        String auth = ":" + personalAccessToken;
        String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes(StandardCharsets.UTF_8));
        request.setHeader(HttpHeaders.AUTHORIZATION, "Basic " + encodedAuth);
        request.setHeader(HttpHeaders.ACCEPT, "application/json");
        
        try (CloseableHttpResponse response = httpClient.execute(request)) {
            String responseBody = EntityUtils.toString(response.getEntity());
            
            if (response.getStatusLine().getStatusCode() != 200) {
                throw new IOException("Azure DevOps API request failed: " + 
                                    response.getStatusLine().getStatusCode() + " - " + responseBody);
            }
            
            return gson.fromJson(responseBody, JsonObject.class);
        }
    }
    
    private AzureDevOpsTestCase parseTestCase(JsonObject workItem) {
        AzureDevOpsTestCase testCase = new AzureDevOpsTestCase();
        
        JsonObject fields = workItem.getAsJsonObject("fields");
        
        testCase.setId(workItem.get("id").getAsInt());
        testCase.setTitle(fields.has("System.Title") ? fields.get("System.Title").getAsString() : "");
        testCase.setDescription(fields.has("System.Description") ? fields.get("System.Description").getAsString() : "");
        
        // Parse test steps
        if (fields.has("Microsoft.VSTS.TCM.Steps")) {
            String steps = fields.get("Microsoft.VSTS.TCM.Steps").getAsString();
            testCase.setTestSteps(parseTestSteps(steps));
        }
        
        // Parse tags
        if (fields.has("System.Tags")) {
            String tagsStr = fields.get("System.Tags").getAsString();
            List<String> tags = new ArrayList<>();
            if (tagsStr != null && !tagsStr.isEmpty()) {
                String[] tagArray = tagsStr.split(";");
                for (String tag : tagArray) {
                    tags.add(tag.trim());
                }
            }
            testCase.setTags(tags);
        }
        
        // Parse area path
        if (fields.has("System.AreaPath")) {
            testCase.setAreaPath(fields.get("System.AreaPath").getAsString());
        }
        
        // Parse iteration path
        if (fields.has("System.IterationPath")) {
            testCase.setIterationPath(fields.get("System.IterationPath").getAsString());
        }
        
        return testCase;
    }
    
    private List<String> parseTestSteps(String stepsXml) {
        List<String> steps = new ArrayList<>();
        if (stepsXml == null || stepsXml.isEmpty()) {
            return steps;
        }
        
        // Parse XML steps (simplified - in production, use proper XML parser)
        // Azure DevOps stores steps in XML format
        String[] stepParts = stepsXml.split("<step");
        for (String stepPart : stepParts) {
            if (stepPart.contains("parameterizedString")) {
                // Extract step text (simplified parsing)
                int start = stepPart.indexOf(">") + 1;
                int end = stepPart.indexOf("<", start);
                if (end > start) {
                    String stepText = stepPart.substring(start, end).trim();
                    if (!stepText.isEmpty()) {
                        steps.add(stepText);
                    }
                }
            }
        }
        
        return steps;
    }
    
    public void close() throws IOException {
        if (httpClient != null) {
            httpClient.close();
        }
    }
}

