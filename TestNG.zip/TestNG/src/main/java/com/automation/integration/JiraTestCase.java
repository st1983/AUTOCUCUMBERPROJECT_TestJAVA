package com.automation.integration;

import java.util.ArrayList;
import java.util.List;

/**
 * JiraTestCase - Data class representing a test case from Jira
 */
public class JiraTestCase {
    private String key;
    private String summary;
    private String description;
    private String testType;
    private List<String> tags = new ArrayList<>();
    private List<String> testSteps = new ArrayList<>();
    private String priority;
    
    // Getters and Setters
    public String getKey() {
        return key;
    }
    
    public void setKey(String key) {
        this.key = key;
    }
    
    public String getSummary() {
        return summary;
    }
    
    public void setSummary(String summary) {
        this.summary = summary;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getTestType() {
        return testType;
    }
    
    public void setTestType(String testType) {
        this.testType = testType;
    }
    
    public List<String> getTags() {
        return tags;
    }
    
    public void setTags(List<String> tags) {
        this.tags = tags;
    }
    
    public List<String> getTestSteps() {
        return testSteps;
    }
    
    public void setTestSteps(List<String> testSteps) {
        this.testSteps = testSteps;
    }
    
    public String getPriority() {
        return priority;
    }
    
    public void setPriority(String priority) {
        this.priority = priority;
    }
}

