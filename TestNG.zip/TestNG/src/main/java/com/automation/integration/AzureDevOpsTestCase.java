package com.automation.integration;

import java.util.ArrayList;
import java.util.List;

/**
 * AzureDevOpsTestCase - Data class representing a test case from Azure DevOps
 */
public class AzureDevOpsTestCase {
    private int id;
    private String title;
    private String description;
    private List<String> tags = new ArrayList<>();
    private List<String> testSteps = new ArrayList<>();
    private String areaPath;
    private String iterationPath;
    
    // Getters and Setters
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public List<String> getTags() {
        return tags;
    }
    
    public void setTags(List<String> tags) {
        this.tags = tags;
    }
    
    public List<String> getTestSteps() {
        return testSteps;
    }
    
    public void setTestSteps(List<String> testSteps) {
        this.testSteps = testSteps;
    }
    
    public String getAreaPath() {
        return areaPath;
    }
    
    public void setAreaPath(String areaPath) {
        this.areaPath = areaPath;
    }
    
    public String getIterationPath() {
        return iterationPath;
    }
    
    public void setIterationPath(String iterationPath) {
        this.iterationPath = iterationPath;
    }
}

