package com.automation.converter;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * TestNGTestParser - Parses TestNG test classes to extract test information
 * This class analyzes Java source files to identify TestNG test methods,
 * setup/teardown methods, and their structure
 */
public class TestNGTestParser {
    
    private static final Pattern TEST_METHOD_PATTERN = Pattern.compile(
        "@Test\\s*(?:\\([^)]*\\))?\\s*\\n\\s*public\\s+void\\s+(\\w+)\\s*\\([^)]*\\)"
    );
    
    private static final Pattern BEFORE_METHOD_PATTERN = Pattern.compile(
        "@BeforeMethod\\s*\\n\\s*public\\s+void\\s+(\\w+)\\s*\\([^)]*\\)"
    );
    
    private static final Pattern AFTER_METHOD_PATTERN = Pattern.compile(
        "@AfterMethod\\s*\\n\\s*public\\s+void\\s+(\\w+)\\s*\\([^)]*\\)"
    );
    
    private static final Pattern BEFORE_CLASS_PATTERN = Pattern.compile(
        "@BeforeClass\\s*\\n\\s*public\\s+void\\s+(\\w+)\\s*\\([^)]*\\)"
    );
    
    private static final Pattern AFTER_CLASS_PATTERN = Pattern.compile(
        "@AfterClass\\s*\\n\\s*public\\s+void\\s+(\\w+)\\s*\\([^)]*\\)"
    );
    
    private static final Pattern CLASS_NAME_PATTERN = Pattern.compile(
        "public\\s+class\\s+(\\w+)\\s*(?:extends\\s+\\w+)?\\s*\\{"
    );
    

    /**
     * Parse a TestNG test class file
     */
    public TestClassInfo parseTestClass(File testFile) throws IOException {
        String content = new String(Files.readAllBytes(testFile.toPath()));
        return parseTestClass(content, testFile.getName());
    }

    /**
     * Parse TestNG test class from content string
     */
    public TestClassInfo parseTestClass(String content, String fileName) {
        TestClassInfo classInfo = new TestClassInfo();
        
        // Extract class name
        Matcher classMatcher = CLASS_NAME_PATTERN.matcher(content);
        if (classMatcher.find()) {
            classInfo.setClassName(classMatcher.group(1));
        }
        classInfo.setFileName(fileName);
        
        // Extract package name
        Pattern packagePattern = Pattern.compile("package\\s+([\\w.]+);");
        Matcher packageMatcher = packagePattern.matcher(content);
        if (packageMatcher.find()) {
            classInfo.setPackageName(packageMatcher.group(1));
        }
        
        // Extract test methods
        List<TestMethodInfo> testMethods = extractTestMethods(content);
        classInfo.setTestMethods(testMethods);
        
        // Extract setup/teardown methods
        classInfo.setBeforeMethod(extractMethod(content, BEFORE_METHOD_PATTERN));
        classInfo.setAfterMethod(extractMethod(content, AFTER_METHOD_PATTERN));
        classInfo.setBeforeClass(extractMethod(content, BEFORE_CLASS_PATTERN));
        classInfo.setAfterClass(extractMethod(content, AFTER_CLASS_PATTERN));
        
        // Extract method bodies for analysis
        extractMethodBodies(content, classInfo);
        
        return classInfo;
    }

    private List<TestMethodInfo> extractTestMethods(String content) {
        List<TestMethodInfo> methods = new ArrayList<>();
        Matcher matcher = TEST_METHOD_PATTERN.matcher(content);
        
        while (matcher.find()) {
            TestMethodInfo methodInfo = new TestMethodInfo();
            methodInfo.setMethodName(matcher.group(1));
            
            // Extract test description from @Test annotation
            int start = matcher.start();
            int annotationStart = content.lastIndexOf("@Test", start);
            if (annotationStart >= 0) {
                String annotation = content.substring(annotationStart, matcher.start());
                methodInfo.setDescription(extractTestDescription(annotation));
                methodInfo.setTags(extractTags(annotation));
            }
            
            methods.add(methodInfo);
        }
        
        return methods;
    }

    private String extractMethod(String content, Pattern pattern) {
        Matcher matcher = pattern.matcher(content);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return null;
    }

    private void extractMethodBodies(String content, TestClassInfo classInfo) {
        // Extract body of each test method
        for (TestMethodInfo method : classInfo.getTestMethods()) {
            String methodBody = extractMethodBody(content, method.getMethodName());
            method.setMethodBody(methodBody);
            method.setPageObjectsUsed(extractPageObjects(methodBody));
            method.setAssertions(extractAssertions(methodBody));
        }
    }

    private String extractMethodBody(String content, String methodName) {
        Pattern pattern = Pattern.compile(
            "public\\s+void\\s+" + methodName + "\\s*\\([^)]*\\)\\s*\\{([^}]+(?:\\{[^}]*\\}[^}]*)*)\\}"
        );
        Matcher matcher = pattern.matcher(content);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return "";
    }

    private List<String> extractPageObjects(String methodBody) {
        List<String> pageObjects = new ArrayList<>();
        Pattern pattern = Pattern.compile("(\\w+Page)\\s*=\\s*new\\s+(\\w+Page)\\(\\)");
        Matcher matcher = pattern.matcher(methodBody);
        while (matcher.find()) {
            pageObjects.add(matcher.group(2));
        }
        return pageObjects;
    }

    private List<String> extractAssertions(String methodBody) {
        List<String> assertions = new ArrayList<>();
        Pattern pattern = Pattern.compile("Assert\\.(assertTrue|assertEquals|assertFalse|assertNotNull)\\s*\\([^)]+\\)");
        Matcher matcher = pattern.matcher(methodBody);
        while (matcher.find()) {
            assertions.add(matcher.group(0));
        }
        return assertions;
    }

    private String extractTestDescription(String annotation) {
        Pattern pattern = Pattern.compile("description\\s*=\\s*\"([^\"]+)\"");
        Matcher matcher = pattern.matcher(annotation);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return null;
    }

    private List<String> extractTags(String annotation) {
        List<String> tags = new ArrayList<>();
        Pattern pattern = Pattern.compile("groups\\s*=\\s*\\{([^}]+)\\}");
        Matcher matcher = pattern.matcher(annotation);
        if (matcher.find()) {
            String groups = matcher.group(1);
            Pattern tagPattern = Pattern.compile("\"([^\"]+)\"");
            Matcher tagMatcher = tagPattern.matcher(groups);
            while (tagMatcher.find()) {
                tags.add(tagMatcher.group(1));
            }
        }
        return tags;
    }

    /**
     * Parse all test classes in a directory
     */
    public List<TestClassInfo> parseTestDirectory(String directoryPath) throws IOException {
        List<TestClassInfo> testClasses = new ArrayList<>();
        Path dir = Paths.get(directoryPath);
        
        if (!Files.exists(dir) || !Files.isDirectory(dir)) {
            throw new IOException("Directory does not exist: " + directoryPath);
        }
        
        Files.walk(dir)
            .filter(Files::isRegularFile)
            .filter(p -> p.toString().endsWith("Test.java") || p.toString().endsWith("Tests.java"))
            .forEach(p -> {
                try {
                    TestClassInfo classInfo = parseTestClass(p.toFile());
                    testClasses.add(classInfo);
                } catch (IOException e) {
                    System.err.println("Error parsing file: " + p + " - " + e.getMessage());
                }
            });
        
        return testClasses;
    }
}

