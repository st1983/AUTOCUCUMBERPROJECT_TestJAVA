package com.automation.converter;

import com.automation.integration.JiraTestCaseFetcher;

import java.io.IOException;
import java.util.Properties;
import java.io.FileInputStream;

/**
 * JiraCucumberConverterRunner - Main runner for Jira to Cucumber conversion
 */
public class JiraCucumberConverterRunner {
    
    public static void main(String[] args) {
        if (args.length < 4) {
            printUsage();
            System.exit(1);
        }
        
        try {
            String jiraUrl = args[0];
            String username = args[1];
            String apiToken = args[2];
            String outputDir = args[3];
            
            // Initialize fetcher
            JiraTestCaseFetcher fetcher = new JiraTestCaseFetcher(jiraUrl, username, apiToken);
            
            // Initialize converter
            JiraToCucumberConverter converter = new JiraToCucumberConverter(outputDir, fetcher);
            
            // Determine conversion type
            if (args.length >= 5) {
                String conversionType = args[4];
                
                switch (conversionType.toLowerCase()) {
                    case "project":
                        if (args.length < 6) {
                            System.err.println("Error: Project key required for project conversion");
                            System.exit(1);
                        }
                        converter.convertFromProject(args[5]);
                        break;
                        
                    case "filter":
                        if (args.length < 6) {
                            System.err.println("Error: Filter ID required for filter conversion");
                            System.exit(1);
                        }
                        converter.convertFromFilter(args[5]);
                        break;
                        
                    case "jql":
                        if (args.length < 6) {
                            System.err.println("Error: JQL query required for JQL conversion");
                            System.exit(1);
                        }
                        String featureName = args.length > 6 ? args[6] : "jira_tests";
                        converter.convertFromJQL(args[5], featureName);
                        break;
                        
                    case "issue":
                        if (args.length < 6) {
                            System.err.println("Error: Issue key required for issue conversion");
                            System.exit(1);
                        }
                        converter.convertTestCase(args[5]);
                        break;
                        
                    default:
                        System.err.println("Error: Unknown conversion type: " + conversionType);
                        printUsage();
                        System.exit(1);
                }
            } else {
                // Use config file
                String configFile = args.length > 4 ? args[4] : "jira-converter-config.properties";
                convertUsingConfig(configFile, fetcher, converter);
            }
            
            fetcher.close();
            System.out.println("\nConversion completed successfully!");
            
        } catch (Exception e) {
            System.err.println("Error during conversion: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
    
    private static void convertUsingConfig(String configFile, JiraTestCaseFetcher fetcher, 
                                          JiraToCucumberConverter converter) throws IOException {
        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(configFile)) {
            props.load(fis);
        }
        
        String conversionType = props.getProperty("conversion.type", "project");
        
        switch (conversionType) {
            case "project":
                String projectKey = props.getProperty("jira.project.key");
                converter.convertFromProject(projectKey);
                break;
                
            case "filter":
                String filterId = props.getProperty("jira.filter.id");
                converter.convertFromFilter(filterId);
                break;
                
            case "jql":
                String jql = props.getProperty("jira.jql");
                String featureName = props.getProperty("feature.name", "jira_tests");
                converter.convertFromJQL(jql, featureName);
                break;
                
            case "issue":
                String issueKey = props.getProperty("jira.issue.key");
                converter.convertTestCase(issueKey);
                break;
        }
    }
    
    private static void printUsage() {
        System.out.println("Jira to Cucumber Converter");
        System.out.println("==========================");
        System.out.println("\nUsage:");
        System.out.println("  java JiraCucumberConverterRunner <jira-url> <username> <api-token> <output-dir> <type> [options]");
        System.out.println("\nTypes:");
        System.out.println("  project <project-key>     - Convert all test cases from a project");
        System.out.println("  filter <filter-id>        - Convert test cases from a filter");
        System.out.println("  jql <jql-query> [name]    - Convert test cases using JQL");
        System.out.println("  issue <issue-key>         - Convert a single test case");
        System.out.println("\nExample:");
        System.out.println("  java JiraCucumberConverterRunner https://yourcompany.atlassian.net user@email.com token123 target/features project PROJ");
        System.out.println("\nOr use config file:");
        System.out.println("  java JiraCucumberConverterRunner <jira-url> <username> <api-token> <output-dir> config.properties");
    }
}

