package com.automation.converter;

import com.automation.integration.JiraTestCase;
import com.automation.integration.JiraTestCaseFetcher;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;

/**
 * JiraToCucumberConverter - Converts Jira test cases to Cucumber feature files
 */
public class JiraToCucumberConverter {
    
    private String outputDirectory;
    private JiraTestCaseFetcher jiraFetcher;
    
    public JiraToCucumberConverter(String outputDirectory, JiraTestCaseFetcher jiraFetcher) {
        this.outputDirectory = outputDirectory;
        this.jiraFetcher = jiraFetcher;
        createOutputDirectory();
    }
    
    private void createOutputDirectory() {
        try {
            Path path = Paths.get(outputDirectory);
            if (!Files.exists(path)) {
                Files.createDirectories(path);
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to create output directory: " + outputDirectory, e);
        }
    }
    
    /**
     * Convert Jira test cases from a project to Cucumber feature files
     */
    public void convertFromProject(String projectKey) throws IOException {
        System.out.println("Fetching test cases from Jira project: " + projectKey);
        List<JiraTestCase> testCases = jiraFetcher.fetchTestCasesFromProject(projectKey);
        System.out.println("Found " + testCases.size() + " test cases");
        
        convertTestCases(testCases, projectKey);
    }
    
    /**
     * Convert Jira test cases from a filter to Cucumber feature files
     */
    public void convertFromFilter(String filterId) throws IOException {
        System.out.println("Fetching test cases from Jira filter: " + filterId);
        List<JiraTestCase> testCases = jiraFetcher.fetchTestCasesFromFilter(filterId);
        System.out.println("Found " + testCases.size() + " test cases");
        
        convertTestCases(testCases, "filter_" + filterId);
    }
    
    /**
     * Convert Jira test cases using JQL to Cucumber feature files
     */
    public void convertFromJQL(String jql, String featureName) throws IOException {
        System.out.println("Fetching test cases using JQL: " + jql);
        List<JiraTestCase> testCases = jiraFetcher.fetchTestCasesByJQL(jql);
        System.out.println("Found " + testCases.size() + " test cases");
        
        convertTestCases(testCases, featureName);
    }
    
    /**
     * Convert a single test case by key
     */
    public void convertTestCase(String issueKey) throws IOException {
        System.out.println("Fetching test case: " + issueKey);
        JiraTestCase testCase = jiraFetcher.fetchTestCaseByKey(issueKey);
        
        String featureFileName = issueKey.replace("-", "_") + ".feature";
        String featureFilePath = Paths.get(outputDirectory, featureFileName).toString();
        
        try (FileWriter writer = new FileWriter(featureFilePath)) {
            writer.write(generateFeatureContent(testCase));
        }
        
        System.out.println("Generated feature file: " + featureFilePath);
    }
    
    private void convertTestCases(List<JiraTestCase> testCases, String featureName) throws IOException {
        // Group test cases by feature/epic (if available) or create one feature file
        String featureFileName = featureName + ".feature";
        String featureFilePath = Paths.get(outputDirectory, featureFileName).toString();
        
        try (FileWriter writer = new FileWriter(featureFilePath)) {
            writer.write(generateFeatureFileHeader(featureName));
            
            for (JiraTestCase testCase : testCases) {
                writer.write(generateScenario(testCase));
            }
        }
        
        System.out.println("Generated feature file: " + featureFilePath);
    }
    
    private String generateFeatureFileHeader(String featureName) {
        StringBuilder sb = new StringBuilder();
        sb.append("Feature: ").append(convertToTitleCase(featureName)).append("\n");
        sb.append("  As a tester\n");
        sb.append("  I want to execute test cases from Jira\n");
        sb.append("  So that I can verify the application functionality\n");
        sb.append("\n");
        return sb.toString();
    }
    
    private String generateFeatureContent(JiraTestCase testCase) {
        StringBuilder sb = new StringBuilder();
        
        // Feature header
        String featureName = testCase.getSummary() != null && !testCase.getSummary().isEmpty() 
            ? testCase.getSummary() 
            : "Test Case " + testCase.getKey();
        sb.append("Feature: ").append(featureName).append("\n");
        sb.append("  Test Case ID: ").append(testCase.getKey()).append("\n");
        if (testCase.getDescription() != null && !testCase.getDescription().isEmpty()) {
            sb.append("  Description: ").append(testCase.getDescription()).append("\n");
        }
        sb.append("\n");
        
        // Scenario
        sb.append(generateScenario(testCase));
        
        return sb.toString();
    }
    
    private String generateScenario(JiraTestCase testCase) {
        StringBuilder sb = new StringBuilder();
        
        // Tags
        if (!testCase.getTags().isEmpty()) {
            String tags = testCase.getTags().stream()
                .map(tag -> "@" + tag.replace(" ", "_"))
                .collect(Collectors.joining(" "));
            sb.append("  ").append(tags).append("\n");
        }
        
        // Priority as tag
        if (testCase.getPriority() != null && !testCase.getPriority().isEmpty()) {
            sb.append("  @").append(testCase.getPriority().toLowerCase().replace(" ", "_")).append("\n");
        }
        
        // Scenario name
        String scenarioName = testCase.getSummary() != null && !testCase.getSummary().isEmpty()
            ? testCase.getSummary()
            : "Test Case " + testCase.getKey();
        sb.append("  Scenario: ").append(scenarioName).append("\n");
        
        // Test Case ID as comment
        sb.append("    # Jira Test Case: ").append(testCase.getKey()).append("\n");
        
        // Generate steps
        if (!testCase.getTestSteps().isEmpty()) {
            for (String step : testCase.getTestSteps()) {
                // Check if step already has Gherkin keyword
                if (step.matches("(?i)^(Given|When|Then|And|But).*")) {
                    sb.append("    ").append(step).append("\n");
                } else {
                    // Convert to Gherkin step
                    sb.append("    ").append(convertToGherkinStep(step)).append("\n");
                }
            }
        } else {
            // Generate default steps if no steps available
            sb.append("    Given I am on the application\n");
            sb.append("    When I perform the test action\n");
            sb.append("    Then the test should pass\n");
        }
        
        sb.append("\n");
        
        return sb.toString();
    }
    
    private String convertToGherkinStep(String step) {
        step = step.trim();
        
        // Try to identify step type based on keywords
        String lowerStep = step.toLowerCase();
        
        if (lowerStep.matches(".*(navigate|go to|open|visit|access).*")) {
            return "Given " + step;
        } else if (lowerStep.matches(".*(click|select|enter|type|input|fill|submit|login|logout).*")) {
            return "When " + step;
        } else if (lowerStep.matches(".*(verify|check|validate|assert|confirm|should|expect).*")) {
            return "Then " + step;
        } else {
            // Default to Given
            return "Given " + step;
        }
    }
    
    private String convertToTitleCase(String text) {
        if (text == null || text.isEmpty()) {
            return text;
        }
        return text.substring(0, 1).toUpperCase() + 
               text.substring(1).replaceAll("([A-Z])", " $1").trim();
    }
}

