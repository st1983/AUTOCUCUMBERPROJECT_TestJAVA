package com.automation.converter;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.List;
import java.util.Properties;
import java.io.FileInputStream;

/**
 * TestNGToCucumberConverter - Main conversion tool
 * Orchestrates the conversion of TestNG tests to Cucumber format
 */
public class TestNGToCucumberConverter {
    
    private TestNGTestParser parser;
    private FeatureFileGenerator featureGenerator;
    private StepDefinitionGenerator stepDefGenerator;
    private HooksGenerator hooksGenerator;
    
    private String testNGSourceDirectory;
    private String cucumberOutputDirectory;
    private String featureOutputDirectory;
    private String stepDefOutputDirectory;
    private String hooksOutputDirectory;
    private String packageName;

    public TestNGToCucumberConverter(String configFile) throws IOException {
        loadConfiguration(configFile);
        initializeGenerators();
    }

    public TestNGToCucumberConverter(String testNGSourceDir, String outputDir, String packageName) {
        this.testNGSourceDirectory = testNGSourceDir;
        this.cucumberOutputDirectory = outputDir;
        this.packageName = packageName;
        
        this.featureOutputDirectory = Paths.get(outputDir, "features").toString();
        this.stepDefOutputDirectory = Paths.get(outputDir, "stepdefinitions").toString();
        this.hooksOutputDirectory = Paths.get(outputDir, "stepdefinitions").toString();
        
        initializeGenerators();
    }

    private void loadConfiguration(String configFile) throws IOException {
        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(configFile)) {
            props.load(fis);
        }
        
        this.testNGSourceDirectory = props.getProperty("testng.source.directory");
        this.cucumberOutputDirectory = props.getProperty("cucumber.output.directory");
        this.packageName = props.getProperty("cucumber.package.name", "com.automation.stepdefinitions");
        
        this.featureOutputDirectory = props.getProperty("feature.output.directory", 
            Paths.get(cucumberOutputDirectory, "features").toString());
        this.stepDefOutputDirectory = props.getProperty("stepdef.output.directory",
            Paths.get(cucumberOutputDirectory, "stepdefinitions").toString());
        this.hooksOutputDirectory = this.stepDefOutputDirectory;
    }

    private void initializeGenerators() {
        this.parser = new TestNGTestParser();
        this.featureGenerator = new FeatureFileGenerator(featureOutputDirectory);
        this.stepDefGenerator = new StepDefinitionGenerator(stepDefOutputDirectory, packageName);
        this.hooksGenerator = new HooksGenerator(hooksOutputDirectory, packageName);
    }

    /**
     * Convert TestNG tests to Cucumber format
     */
    public void convert() throws IOException {
        System.out.println("Starting TestNG to Cucumber conversion...");
        System.out.println("Source directory: " + testNGSourceDirectory);
        System.out.println("Output directory: " + cucumberOutputDirectory);
        
        // Parse TestNG test classes
        System.out.println("\nParsing TestNG test classes...");
        List<TestClassInfo> testClasses = parser.parseTestDirectory(testNGSourceDirectory);
        System.out.println("Found " + testClasses.size() + " test class(es)");
        
        if (testClasses.isEmpty()) {
            System.out.println("No test classes found. Exiting.");
            return;
        }
        
        // Generate feature files
        System.out.println("\nGenerating feature files...");
        featureGenerator.generateFeatureFiles(testClasses);
        
        // Generate step definitions
        System.out.println("\nGenerating step definitions...");
        stepDefGenerator.generateStepDefinitions(testClasses);
        
        // Generate hooks
        System.out.println("\nGenerating hooks...");
        hooksGenerator.generateHooks(testClasses);
        
        System.out.println("\nConversion completed successfully!");
        System.out.println("\nGenerated files:");
        System.out.println("  - Feature files: " + featureOutputDirectory);
        System.out.println("  - Step definitions: " + stepDefOutputDirectory);
        System.out.println("  - Hooks: " + hooksOutputDirectory + "/Hooks.java");
        System.out.println("\nPlease review and customize the generated files as needed.");
    }

    /**
     * Main method to run the converter
     */
    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println("Usage: TestNGToCucumberConverter <testng-source-dir> <cucumber-output-dir> [package-name]");
            System.out.println("   OR: TestNGToCucumberConverter <config-file>");
            System.out.println("\nExample:");
            System.out.println("  java TestNGToCucumberConverter src/test/java/com/example/tests target/cucumber com.example.stepdefinitions");
            System.exit(1);
        }
        
        try {
            TestNGToCucumberConverter converter;
            
            if (args.length == 1) {
                // Use config file
                converter = new TestNGToCucumberConverter(args[0]);
            } else {
                // Use command line arguments
                String packageName = args.length > 2 ? args[2] : "com.automation.stepdefinitions";
                converter = new TestNGToCucumberConverter(args[0], args[1], packageName);
            }
            
            converter.convert();
            
        } catch (Exception e) {
            System.err.println("Error during conversion: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
}

