package com.automation.converter;

import java.util.ArrayList;
import java.util.List;

/**
 * TestClassInfo - Data class to hold information about a TestNG test class
 */
public class TestClassInfo {
    private String className;
    private String fileName;
    private String packageName;
    private List<TestMethodInfo> testMethods = new ArrayList<>();
    private String beforeMethod;
    private String afterMethod;
    private String beforeClass;
    private String afterClass;

    // Getters and Setters
    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public List<TestMethodInfo> getTestMethods() {
        return testMethods;
    }

    public void setTestMethods(List<TestMethodInfo> testMethods) {
        this.testMethods = testMethods;
    }

    public String getBeforeMethod() {
        return beforeMethod;
    }

    public void setBeforeMethod(String beforeMethod) {
        this.beforeMethod = beforeMethod;
    }

    public String getAfterMethod() {
        return afterMethod;
    }

    public void setAfterMethod(String afterMethod) {
        this.afterMethod = afterMethod;
    }

    public String getBeforeClass() {
        return beforeClass;
    }

    public void setBeforeClass(String beforeClass) {
        this.beforeClass = beforeClass;
    }

    public String getAfterClass() {
        return afterClass;
    }

    public void setAfterClass(String afterClass) {
        this.afterClass = afterClass;
    }
}

