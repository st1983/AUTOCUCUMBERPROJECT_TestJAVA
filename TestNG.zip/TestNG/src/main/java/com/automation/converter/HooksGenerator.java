package com.automation.converter;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Set;
import java.util.HashSet;

/**
 * HooksGenerator - Generates Cucumber Hooks class from TestNG setup/teardown methods
 */
public class HooksGenerator {
    
    private String outputDirectory;
    private String packageName;

    public HooksGenerator(String outputDirectory, String packageName) {
        this.outputDirectory = outputDirectory;
        this.packageName = packageName;
        createOutputDirectory();
    }

    private void createOutputDirectory() {
        try {
            Path path = Paths.get(outputDirectory);
            if (!Files.exists(path)) {
                Files.createDirectories(path);
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to create output directory: " + outputDirectory, e);
        }
    }

    /**
     * Generate Hooks class from TestNG test classes
     */
    public void generateHooks(List<TestClassInfo> testClasses) throws IOException {
        String hooksFilePath = Paths.get(outputDirectory, "Hooks.java").toString();
        
        try (FileWriter writer = new FileWriter(hooksFilePath)) {
            writer.write(generateHooksContent(testClasses));
        }
        
        System.out.println("Generated Hooks class: " + hooksFilePath);
    }

    private String generateHooksContent(List<TestClassInfo> testClasses) {
        StringBuilder sb = new StringBuilder();
        
        // Package declaration
        sb.append("package ").append(packageName).append(";\n\n");
        
        // Imports
        sb.append("import com.automation.utils.DriverManager;\n");
        sb.append("import com.automation.utils.ExtentReportManager;\n");
        sb.append("import com.automation.utils.ConfigReader;\n");
        sb.append("import com.aventstack.extentreports.ExtentTest;\n");
        sb.append("import io.cucumber.java.After;\n");
        sb.append("import io.cucumber.java.Before;\n");
        sb.append("import io.cucumber.java.Scenario;\n");
        sb.append("import org.openqa.selenium.OutputType;\n");
        sb.append("import org.openqa.selenium.TakesScreenshot;\n");
        sb.append("import java.util.Base64;\n\n");
        
        // Class declaration
        sb.append("/**\n");
        sb.append(" * Hooks class - Generated from TestNG @BeforeMethod and @AfterMethod\n");
        sb.append(" * Handles setup and teardown for each scenario\n");
        sb.append(" */\n");
        sb.append("public class Hooks {\n\n");
        
        // Collect all setup/teardown methods
        Set<String> beforeMethods = new HashSet<>();
        Set<String> afterMethods = new HashSet<>();
        Set<String> beforeClassMethods = new HashSet<>();
        Set<String> afterClassMethods = new HashSet<>();
        
        for (TestClassInfo testClass : testClasses) {
            if (testClass.getBeforeMethod() != null) {
                beforeMethods.add(testClass.getBeforeMethod());
            }
            if (testClass.getAfterMethod() != null) {
                afterMethods.add(testClass.getAfterMethod());
            }
            if (testClass.getBeforeClass() != null) {
                beforeClassMethods.add(testClass.getBeforeClass());
            }
            if (testClass.getAfterClass() != null) {
                afterClassMethods.add(testClass.getAfterClass());
            }
        }
        
        // Generate @Before hook
        sb.append("    @Before\n");
        sb.append("    public void setUp(Scenario scenario) {\n");
        sb.append("        System.out.println(\"Starting scenario: \" + scenario.getName());\n");
        sb.append("        \n");
        sb.append("        // Initialize Extent Test for this scenario\n");
        sb.append("        ExtentTest test = ExtentReportManager.createTest(\n");
        sb.append("            scenario.getName(),\n");
        sb.append("            scenario.getUri().toString()\n");
        sb.append("        );\n");
        sb.append("        ExtentReportManager.logInfo(\"Browser: \" + ConfigReader.getProperty(\"browser\", \"Chrome\"));\n");
        sb.append("        \n");
        sb.append("        // Initialize WebDriver\n");
        sb.append("        DriverManager.initializeDriver();\n");
        sb.append("        ExtentReportManager.logInfo(\"WebDriver initialized\");\n");
        
        // Add common setup from @BeforeMethod
        if (!beforeMethods.isEmpty()) {
            sb.append("        \n");
            sb.append("        // Setup from TestNG @BeforeMethod\n");
            // In a real implementation, you would parse and convert the method body
            sb.append("        // TODO: Add setup logic from @BeforeMethod if needed\n");
        }
        
        sb.append("    }\n\n");
        
        // Generate @After hook
        sb.append("    @After\n");
        sb.append("    public void tearDown(Scenario scenario) {\n");
        sb.append("        ExtentTest test = ExtentReportManager.getTest();\n");
        sb.append("        \n");
        sb.append("        if (scenario.isFailed()) {\n");
        sb.append("            // Take screenshot on failure\n");
        sb.append("            try {\n");
        sb.append("                byte[] screenshot = ((TakesScreenshot) DriverManager.getDriver())\n");
        sb.append("                        .getScreenshotAs(OutputType.BYTES);\n");
        sb.append("                String base64Screenshot = Base64.getEncoder().encodeToString(screenshot);\n");
        sb.append("                \n");
        sb.append("                // Attach to Cucumber report\n");
        sb.append("                scenario.attach(screenshot, \"image/png\", \"Screenshot\");\n");
        sb.append("                \n");
        sb.append("                // Attach to Extent Report\n");
        sb.append("                ExtentReportManager.addScreenshot(base64Screenshot, \"Failure Screenshot\");\n");
        sb.append("                ExtentReportManager.logFail(\"Scenario failed: \" + scenario.getName());\n");
        sb.append("                \n");
        sb.append("                // Log error details if available\n");
        sb.append("                if (scenario.getSourceTagNames() != null) {\n");
        sb.append("                    ExtentReportManager.logInfo(\"Tags: \" + scenario.getSourceTagNames().toString());\n");
        sb.append("                }\n");
        sb.append("            } catch (Exception e) {\n");
        sb.append("                ExtentReportManager.logWarning(\"Failed to capture screenshot: \" + e.getMessage());\n");
        sb.append("            }\n");
        sb.append("        } else {\n");
        sb.append("            ExtentReportManager.logPass(\"Scenario passed: \" + scenario.getName());\n");
        sb.append("        }\n");
        sb.append("        \n");
        sb.append("        System.out.println(\"Ending scenario: \" + scenario.getName() + \" - Status: \" + \n");
        sb.append("            (scenario.isFailed() ? \"FAILED\" : \"PASSED\"));\n");
        sb.append("        \n");
        sb.append("        // Quit WebDriver\n");
        sb.append("        DriverManager.quitDriver();\n");
        sb.append("        ExtentReportManager.logInfo(\"WebDriver closed\");\n");
        sb.append("        \n");
        sb.append("        // Remove test from thread local\n");
        sb.append("        ExtentReportManager.removeTest(Thread.currentThread().getName());\n");
        
        // Add common teardown from @AfterMethod
        if (!afterMethods.isEmpty()) {
            sb.append("        \n");
            sb.append("        // Teardown from TestNG @AfterMethod\n");
            sb.append("        // TODO: Add teardown logic from @AfterMethod if needed\n");
        }
        
        sb.append("    }\n");
        
        // Generate @BeforeClass equivalent (if needed)
        if (!beforeClassMethods.isEmpty()) {
            sb.append("\n    // Note: @BeforeClass equivalent should be handled in TestRunner or separate hook\n");
        }
        
        sb.append("}\n");
        
        return sb.toString();
    }
}

