package com.automation.converter;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

/**
 * StepDefinitionGenerator - Generates Cucumber step definitions from TestNG test methods
 */
public class StepDefinitionGenerator {
    
    private String outputDirectory;
    private String packageName;

    public StepDefinitionGenerator(String outputDirectory, String packageName) {
        this.outputDirectory = outputDirectory;
        this.packageName = packageName;
        createOutputDirectory();
    }

    private void createOutputDirectory() {
        try {
            Path path = Paths.get(outputDirectory);
            if (!Files.exists(path)) {
                Files.createDirectories(path);
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to create output directory: " + outputDirectory, e);
        }
    }

    /**
     * Generate step definitions file from TestNG test class
     */
    public void generateStepDefinitions(TestClassInfo testClass) throws IOException {
        String stepDefFileName = testClass.getClassName().replace("Test", "StepDefinitions") + ".java";
        String stepDefFilePath = Paths.get(outputDirectory, stepDefFileName).toString();
        
        try (FileWriter writer = new FileWriter(stepDefFilePath)) {
            writer.write(generateStepDefinitionsContent(testClass));
        }
        
        System.out.println("Generated step definitions: " + stepDefFilePath);
    }

    private String generateStepDefinitionsContent(TestClassInfo testClass) {
        StringBuilder sb = new StringBuilder();
        
        // Package declaration
        sb.append("package ").append(packageName).append(";\n\n");
        
        // Imports
        sb.append("import io.cucumber.java.en.Given;\n");
        sb.append("import io.cucumber.java.en.When;\n");
        sb.append("import io.cucumber.java.en.Then;\n");
        sb.append("import io.cucumber.java.en.And;\n");
        sb.append("import org.junit.Assert;\n");
        sb.append("import com.automation.utils.ExtentReportManager;\n\n");
        
        // Add page object imports
        Set<String> pageObjects = new HashSet<>();
        for (TestMethodInfo method : testClass.getTestMethods()) {
            pageObjects.addAll(method.getPageObjectsUsed());
        }
        
        for (String pageObject : pageObjects) {
            // Assuming page objects are in com.automation.pages package
            sb.append("import com.automation.pages.").append(pageObject).append(";\n");
        }
        sb.append("\n");
        
        // Class declaration
        String className = testClass.getClassName().replace("Test", "StepDefinitions");
        sb.append("/**\n");
        sb.append(" * ").append(className).append(" - Step definitions for ").append(testClass.getClassName()).append("\n");
        sb.append(" * Auto-generated from TestNG test class\n");
        sb.append(" */\n");
        sb.append("public class ").append(className).append(" {\n\n");
        
        // Page object fields
        for (String pageObject : pageObjects) {
            String fieldName = Character.toLowerCase(pageObject.charAt(0)) + pageObject.substring(1);
            sb.append("    private ").append(pageObject).append(" ").append(fieldName).append(";\n");
        }
        sb.append("\n");
        
        // Constructor
        sb.append("    public ").append(className).append("() {\n");
        for (String pageObject : pageObjects) {
            String fieldName = Character.toLowerCase(pageObject.charAt(0)) + pageObject.substring(1);
            sb.append("        this.").append(fieldName).append(" = new ").append(pageObject).append("();\n");
        }
        sb.append("    }\n\n");
        
        // Generate step definitions from test methods
        for (TestMethodInfo testMethod : testClass.getTestMethods()) {
            generateStepDefinitionsForMethod(sb, testMethod, testClass);
        }
        
        sb.append("}\n");
        
        return sb.toString();
    }

    private void generateStepDefinitionsForMethod(StringBuilder sb, TestMethodInfo testMethod, TestClassInfo testClass) {
        String methodBody = testMethod.getMethodBody();
        
        // Generate Given steps
        if (methodBody.contains("navigateTo") || methodBody.contains("new LoginPage()")) {
            sb.append("    @Given(\"I am on the login page\")\n");
            sb.append("    public void i_am_on_the_login_page() {\n");
            sb.append("        ExtentReportManager.logInfo(\"Navigating to login page\");\n");
            sb.append("        loginPage.navigateTo(\"https://example.com/login\");\n");
            sb.append("    }\n\n");
        }
        
        // Generate When steps
        if (methodBody.contains(".login(")) {
            sb.append("    @When(\"I login with username {string} and password {string}\")\n");
            sb.append("    public void i_login_with_username_and_password(String username, String password) {\n");
            sb.append("        ExtentReportManager.logInfo(\"Logging in with username: \" + username);\n");
            sb.append("        loginPage.login(username, password);\n");
            sb.append("    }\n\n");
        }
        
        // Generate Then steps from assertions
        for (int i = 0; i < testMethod.getAssertions().size(); i++) {
            String assertion = testMethod.getAssertions().get(i);
            sb.append("    @Then(\"I should see the expected result\")\n");
            sb.append("    public void i_should_see_the_expected_result() {\n");
            sb.append("        ExtentReportManager.logInfo(\"Verifying expected result\");\n");
            // Convert TestNG Assert to JUnit Assert
            String junitAssertion = assertion.replace("Assert.", "Assert.");
            sb.append("        ").append(junitAssertion).append(";\n");
            sb.append("        ExtentReportManager.logPass(\"Assertion passed\");\n");
            sb.append("    }\n\n");
        }
        
        // If no specific steps, generate generic ones
        if (!methodBody.contains("navigateTo") && !methodBody.contains(".login(") && testMethod.getAssertions().isEmpty()) {
            sb.append("    @Given(\"I perform the test action\")\n");
            sb.append("    public void i_perform_the_test_action() {\n");
            sb.append("        // TODO: Implement step definition based on: ").append(testMethod.getMethodName()).append("\n");
            sb.append("    }\n\n");
            
            sb.append("    @Then(\"the test should pass\")\n");
            sb.append("    public void the_test_should_pass() {\n");
            sb.append("        // TODO: Add assertion\n");
            sb.append("    }\n\n");
        }
    }

    /**
     * Generate step definitions for all test classes
     */
    public void generateStepDefinitions(List<TestClassInfo> testClasses) throws IOException {
        for (TestClassInfo testClass : testClasses) {
            generateStepDefinitions(testClass);
        }
    }
}

