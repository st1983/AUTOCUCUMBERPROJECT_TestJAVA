package com.automation.converter;

import com.automation.integration.AzureDevOpsTestCaseFetcher;

import java.io.IOException;
import java.util.Properties;
import java.io.FileInputStream;

/**
 * AzureDevOpsCucumberConverterRunner - Main runner for Azure DevOps to Cucumber conversion
 */
public class AzureDevOpsCucumberConverterRunner {
    
    public static void main(String[] args) {
        if (args.length < 5) {
            printUsage();
            System.exit(1);
        }
        
        try {
            String organization = args[0];
            String project = args[1];
            String personalAccessToken = args[2];
            String outputDir = args[3];
            
            // Initialize fetcher
            AzureDevOpsTestCaseFetcher fetcher = new AzureDevOpsTestCaseFetcher(
                organization, project, personalAccessToken
            );
            
            // Initialize converter
            AzureDevOpsToCucumberConverter converter = new AzureDevOpsToCucumberConverter(outputDir, fetcher);
            
            // Determine conversion type
            if (args.length >= 5) {
                String conversionType = args[4];
                
                switch (conversionType.toLowerCase()) {
                    case "testplan":
                        if (args.length < 6) {
                            System.err.println("Error: Test Plan ID required");
                            System.exit(1);
                        }
                        int testPlanId = Integer.parseInt(args[5]);
                        String featureName = args.length > 6 ? args[6] : "test_plan_" + testPlanId;
                        converter.convertFromTestPlan(testPlanId, featureName);
                        break;
                        
                    case "testsuite":
                        if (args.length < 7) {
                            System.err.println("Error: Test Plan ID and Suite ID required");
                            System.exit(1);
                        }
                        int planId = Integer.parseInt(args[5]);
                        int suiteId = Integer.parseInt(args[6]);
                        String suiteFeatureName = args.length > 7 ? args[7] : "test_suite_" + suiteId;
                        converter.convertFromTestSuite(planId, suiteId, suiteFeatureName);
                        break;
                        
                    case "testcase":
                        if (args.length < 6) {
                            System.err.println("Error: Work Item ID required");
                            System.exit(1);
                        }
                        int workItemId = Integer.parseInt(args[5]);
                        converter.convertTestCase(workItemId);
                        break;
                        
                    default:
                        System.err.println("Error: Unknown conversion type: " + conversionType);
                        printUsage();
                        System.exit(1);
                }
            } else {
                // Use config file
                String configFile = args[4];
                convertUsingConfig(configFile, fetcher, converter);
            }
            
            fetcher.close();
            System.out.println("\nConversion completed successfully!");
            
        } catch (Exception e) {
            System.err.println("Error during conversion: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
    
    private static void convertUsingConfig(String configFile, AzureDevOpsTestCaseFetcher fetcher,
                                          AzureDevOpsToCucumberConverter converter) throws IOException {
        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(configFile)) {
            props.load(fis);
        }
        
        String conversionType = props.getProperty("conversion.type", "testplan");
        
        switch (conversionType) {
            case "testplan":
                int testPlanId = Integer.parseInt(props.getProperty("ado.testplan.id"));
                String featureName = props.getProperty("feature.name", "test_plan_" + testPlanId);
                converter.convertFromTestPlan(testPlanId, featureName);
                break;
                
            case "testsuite":
                int planId = Integer.parseInt(props.getProperty("ado.testplan.id"));
                int suiteId = Integer.parseInt(props.getProperty("ado.testsuite.id"));
                String suiteFeatureName = props.getProperty("feature.name", "test_suite_" + suiteId);
                converter.convertFromTestSuite(planId, suiteId, suiteFeatureName);
                break;
                
            case "testcase":
                int workItemId = Integer.parseInt(props.getProperty("ado.workitem.id"));
                converter.convertTestCase(workItemId);
                break;
        }
    }
    
    private static void printUsage() {
        System.out.println("Azure DevOps to Cucumber Converter");
        System.out.println("===================================");
        System.out.println("\nUsage:");
        System.out.println("  java AzureDevOpsCucumberConverterRunner <org> <project> <pat> <output-dir> <type> [options]");
        System.out.println("\nTypes:");
        System.out.println("  testplan <plan-id> [name]      - Convert all test cases from a test plan");
        System.out.println("  testsuite <plan-id> <suite-id> [name] - Convert test cases from a test suite");
        System.out.println("  testcase <workitem-id>          - Convert a single test case");
        System.out.println("\nExample:");
        System.out.println("  java AzureDevOpsCucumberConverterRunner myorg myproject pat123 target/features testplan 12345");
        System.out.println("\nOr use config file:");
        System.out.println("  java AzureDevOpsCucumberConverterRunner <org> <project> <pat> <output-dir> config.properties");
    }
}

