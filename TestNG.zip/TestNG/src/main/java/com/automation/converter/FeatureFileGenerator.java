package com.automation.converter;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * FeatureFileGenerator - Generates Cucumber feature files from TestNG test classes
 */
public class FeatureFileGenerator {
    
    private String outputDirectory;

    public FeatureFileGenerator(String outputDirectory) {
        this.outputDirectory = outputDirectory;
        createOutputDirectory();
    }

    private void createOutputDirectory() {
        try {
            Path path = Paths.get(outputDirectory);
            if (!Files.exists(path)) {
                Files.createDirectories(path);
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to create output directory: " + outputDirectory, e);
        }
    }

    /**
     * Generate feature file from TestNG test class
     */
    public void generateFeatureFile(TestClassInfo testClass) throws IOException {
        String featureFileName = testClass.getClassName().replace("Test", "") + ".feature";
        String featureFilePath = Paths.get(outputDirectory, featureFileName).toString();
        
        try (FileWriter writer = new FileWriter(featureFilePath)) {
            writer.write(generateFeatureContent(testClass));
        }
        
        System.out.println("Generated feature file: " + featureFilePath);
    }

    private String generateFeatureContent(TestClassInfo testClass) {
        StringBuilder sb = new StringBuilder();
        
        // Feature header
        String featureName = testClass.getClassName().replace("Test", "");
        featureName = convertToTitleCase(featureName);
        
        sb.append("@").append(featureName.toLowerCase()).append("\n");
        sb.append("Feature: ").append(featureName).append("\n");
        sb.append("  As a user\n");
        sb.append("  I want to test ").append(featureName.toLowerCase()).append(" functionality\n");
        sb.append("  So that I can verify the application works correctly\n");
        sb.append("\n");
        
        // Background (if there's a beforeMethod)
        if (testClass.getBeforeMethod() != null) {
            sb.append("  Background:\n");
            sb.append("    Given the test environment is set up\n");
            sb.append("\n");
        }
        
        // Scenarios from test methods
        for (TestMethodInfo testMethod : testClass.getTestMethods()) {
            generateScenario(sb, testMethod, testClass);
        }
        
        return sb.toString();
    }

    private void generateScenario(StringBuilder sb, TestMethodInfo testMethod, TestClassInfo testClass) {
        // Tags
        if (!testMethod.getTags().isEmpty()) {
            String tags = testMethod.getTags().stream()
                .map(tag -> "@" + tag)
                .collect(Collectors.joining(" "));
            sb.append("  ").append(tags).append("\n");
        }
        
        // Scenario name
        String scenarioName = testMethod.getDescription() != null 
            ? testMethod.getDescription() 
            : testMethod.getScenarioName();
        sb.append("  Scenario: ").append(scenarioName).append("\n");
        
        // Generate steps from method body
        List<String> steps = generateStepsFromMethod(testMethod);
        for (String step : steps) {
            sb.append("    ").append(step).append("\n");
        }
        
        sb.append("\n");
    }

    private List<String> generateStepsFromMethod(TestMethodInfo testMethod) {
        List<String> steps = new ArrayList<>();
        String body = testMethod.getMethodBody();
        
        // Analyze method body and generate steps
        // This is a simplified version - you can enhance this based on your needs
        
        // Check for page object instantiation
        if (body.contains("new LoginPage()")) {
            steps.add("Given I am on the login page");
        }
        
        // Check for login calls
        if (body.contains(".login(")) {
            steps.add("When I login with valid credentials");
        }
        
        // Check for navigation
        if (body.contains(".navigateTo(")) {
            steps.add("Given I navigate to the application");
        }
        
        // Check for assertions
        for (String assertion : testMethod.getAssertions()) {
            if (assertion.contains("assertTrue")) {
                steps.add("Then I should see the expected result");
            } else if (assertion.contains("assertEquals")) {
                steps.add("Then the values should match");
            }
        }
        
        // If no steps were generated, add a generic step
        if (steps.isEmpty()) {
            steps.add("Given I perform the test action");
            steps.add("Then the test should pass");
        }
        
        return steps;
    }

    private String convertToTitleCase(String text) {
        if (text == null || text.isEmpty()) {
            return text;
        }
        return text.substring(0, 1).toUpperCase() + 
               text.substring(1).replaceAll("([A-Z])", " $1").trim();
    }

    /**
     * Generate feature files for all test classes
     */
    public void generateFeatureFiles(List<TestClassInfo> testClasses) throws IOException {
        for (TestClassInfo testClass : testClasses) {
            generateFeatureFile(testClass);
        }
    }
}

