package com.automation.converter;

import java.util.ArrayList;
import java.util.List;

/**
 * TestMethodInfo - Data class to hold information about a TestNG test method
 */
public class TestMethodInfo {
    private String methodName;
    private String description;
    private List<String> tags = new ArrayList<>();
    private String methodBody;
    private List<String> pageObjectsUsed = new ArrayList<>();
    private List<String> assertions = new ArrayList<>();

    // Getters and Setters
    public String getMethodName() {
        return methodName;
    }

    public void setMethodName(String methodName) {
        this.methodName = methodName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    public String getMethodBody() {
        return methodBody;
    }

    public void setMethodBody(String methodBody) {
        this.methodBody = methodBody;
    }

    public List<String> getPageObjectsUsed() {
        return pageObjectsUsed;
    }

    public void setPageObjectsUsed(List<String> pageObjectsUsed) {
        this.pageObjectsUsed = pageObjectsUsed;
    }

    public List<String> getAssertions() {
        return assertions;
    }

    public void setAssertions(List<String> assertions) {
        this.assertions = assertions;
    }

    /**
     * Generate scenario name from method name
     */
    public String getScenarioName() {
        String name = methodName;
        // Remove 'test' prefix if present
        if (name.startsWith("test")) {
            name = name.substring(4);
        }
        // Convert camelCase to Title Case
        name = name.replaceAll("([A-Z])", " $1").trim();
        return name.isEmpty() ? methodName : name;
    }
}

