package com.automation.converter;

import java.io.IOException;

/**
 * ConversionScript - Simple script runner for the conversion tool
 * This can be used as an entry point for Maven exec plugin
 */
public class ConversionScript {
    
    public static void main(String[] args) {
        try {
            TestNGToCucumberConverter converter;
            
            if (args.length == 0) {
                // Use default configuration
                String configFile = "src/main/resources/converter-config.properties";
                converter = new TestNGToCucumberConverter(configFile);
            } else if (args.length == 1) {
                // Use config file
                converter = new TestNGToCucumberConverter(args[0]);
            } else if (args.length >= 2) {
                // Use command line arguments
                String packageName = args.length > 2 ? args[2] : "com.automation.stepdefinitions";
                converter = new TestNGToCucumberConverter(args[0], args[1], packageName);
            } else {
                printUsage();
                return;
            }
            
            converter.convert();
            
        } catch (IOException e) {
            System.err.println("Error during conversion: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        } catch (Exception e) {
            System.err.println("Unexpected error: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
    
    private static void printUsage() {
        System.out.println("TestNG to Cucumber Conversion Tool");
        System.out.println("===================================");
        System.out.println("\nUsage:");
        System.out.println("  java ConversionScript [config-file]");
        System.out.println("  java ConversionScript <testng-source-dir> <cucumber-output-dir> [package-name]");
        System.out.println("\nExamples:");
        System.out.println("  # Using config file:");
        System.out.println("  java ConversionScript src/main/resources/converter-config.properties");
        System.out.println("\n  # Using command line:");
        System.out.println("  java ConversionScript src/test/java/com/example/tests target/cucumber-output com.example.stepdefinitions");
    }
}

