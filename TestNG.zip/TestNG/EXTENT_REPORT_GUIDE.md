# Extent Report Integration Guide

## Overview

This framework includes full Extent Report integration for Cucumber tests, providing comprehensive test execution reports with screenshots, logs, and detailed test information.

## Features

✅ **Automatic Report Generation** - Reports generated after each test run  
✅ **Screenshot Capture** - Automatic screenshots on test failures  
✅ **Detailed Logging** - Step-by-step logging of test execution  
✅ **Thread-Safe** - Supports parallel test execution  
✅ **Customizable** - Configurable themes and settings  
✅ **HTML Reports** - Beautiful, interactive HTML reports  

## Configuration

### 1. Extent Properties File

Location: `src/test/resources/extent.properties`

```properties
# Report Settings
extent.reporter.spark.start=true
extent.reporter.spark.out=test-output/ExtentReports/ExtentReport.html
extent.reporter.spark.config=src/test/resources/extent-config.xml

# System Information
systeminfo.OS=Windows
systeminfo.OSVersion=10
systeminfo.Browser=Chrome

# Screenshot Settings
screenshot.dir=test-output/Screenshots/
screenshot.rel.path=../Screenshots/

# Report Theme (STANDARD, DARK)
theme=STANDARD
```

### 2. Extent Config XML

Location: `src/test/resources/extent-config.xml`

Customize report appearance, theme, and styling.

### 3. TestRunner Configuration

The TestRunner includes the Extent Report adapter:

```java
@CucumberOptions(
    plugin = {
        "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
    }
)
```

## Usage

### Automatic Integration

Extent Reports are automatically integrated through:

1. **Hooks Class** - Captures scenario start/end and failures
2. **Step Definitions** - Logs step execution (when using ExtentReportManager)
3. **Screenshot Capture** - Automatic on test failures

### Manual Logging

You can add custom logging in step definitions:

```java
@Given("I am on the login page")
public void i_am_on_the_login_page() {
    ExtentReportManager.logInfo("Navigating to login page");
    loginPage.navigateTo("https://example.com/login");
    ExtentReportManager.logPass("Successfully navigated to login page");
}
```

### Logging Methods

- `ExtentReportManager.logInfo(String message)` - Info log
- `ExtentReportManager.logPass(String message)` - Pass log
- `ExtentReportManager.logFail(String message)` - Fail log
- `ExtentReportManager.logSkip(String message)` - Skip log
- `ExtentReportManager.logWarning(String message)` - Warning log

### Screenshot Methods

- `ExtentReportManager.addScreenshot(String base64Screenshot, String title)` - Add base64 screenshot
- `ExtentReportManager.addScreenshot(String screenshotPath)` - Add screenshot from path

## Report Location

Reports are generated in: `test-output/ExtentReports/`

File naming: `ExtentReport_YYYY-MM-DD_HH-mm-ss.html`

## Report Features

### 1. Dashboard
- Test execution summary
- Pass/Fail/Skip statistics
- Execution time
- System information

### 2. Test Details
- Scenario names and descriptions
- Step-by-step execution logs
- Screenshots on failures
- Error messages and stack traces
- Tags and categories

### 3. Screenshots
- Automatically captured on test failures
- Can be manually added in step definitions
- Base64 encoded for embedding

## Integration with Conversion Tool

The conversion tool automatically generates step definitions with Extent Report logging:

```java
@Given("I am on the login page")
public void i_am_on_the_login_page() {
    ExtentReportManager.logInfo("Navigating to login page");
    loginPage.navigateTo("https://example.com/login");
}
```

Hooks are also generated with Extent Report integration:

```java
@Before
public void setUp(Scenario scenario) {
    ExtentTest test = ExtentReportManager.createTest(
        scenario.getName(),
        scenario.getUri().toString()
    );
    ExtentReportManager.logInfo("Browser: " + ConfigReader.getProperty("browser"));
    DriverManager.initializeDriver();
}

@After
public void tearDown(Scenario scenario) {
    if (scenario.isFailed()) {
        // Screenshot and logging automatically handled
    }
    ExtentReportManager.removeTest(Thread.currentThread().getName());
}
```

## Customization

### Change Report Theme

Edit `extent-config.xml`:
```xml
<theme>DARK</theme>  <!-- or STANDARD -->
```

### Customize Report Title

Edit `extent.properties`:
```properties
document.title=My Custom Test Report
report.name=My Test Execution Report
```

### Add System Information

Edit `ExtentReportManager.java`:
```java
extent.setSystemInfo("Environment", "QA");
extent.setSystemInfo("Build", "1.0.0");
```

## Best Practices

1. **Use Descriptive Logs** - Add meaningful log messages
2. **Capture Screenshots** - On failures and key steps
3. **Organize by Tags** - Use tags for better report organization
4. **Review Reports** - Regularly review reports for insights
5. **Clean Old Reports** - Archive or delete old reports periodically

## Troubleshooting

### Reports Not Generated

- Check `extent.properties` file exists
- Verify Extent Report adapter in TestRunner
- Check file permissions for report directory

### Screenshots Not Appearing

- Verify screenshot capture in Hooks
- Check base64 encoding
- Ensure WebDriver is active when capturing

### Missing Logs

- Verify ExtentReportManager calls in step definitions
- Check thread safety for parallel execution
- Ensure test is created before logging

## Example Report Structure

```
ExtentReport_2024-01-15_10-30-45.html
├── Dashboard
│   ├── Test Summary
│   ├── System Info
│   └── Charts
├── Test Details
│   ├── Feature: Login
│   │   ├── Scenario: Successful login
│   │   │   ├── Step: Given I am on login page [PASS]
│   │   │   ├── Step: When I login [PASS]
│   │   │   └── Step: Then I should see home page [PASS]
│   │   └── Scenario: Failed login
│   │       ├── Step: Given I am on login page [PASS]
│   │       ├── Step: When I login with invalid credentials [FAIL]
│   │       └── Screenshot: Failure Screenshot
└── Settings
```

## Additional Resources

- [Extent Reports Documentation](https://www.extentreports.com/)
- [Cucumber Extent Adapter](https://github.com/anshooarora/extentreports-cucumber7-adapter)

