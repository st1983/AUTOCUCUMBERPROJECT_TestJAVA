# Quick Conversion Reference - TestNG to Cucumber

## 🚀 Quick Start (5 Steps)

### 1. Configure
Edit `src/main/resources/converter-config.properties`:
```properties
testng.source.directory=src/test/java/com/yourcompany/tests
cucumber.output.directory=target/cucumber-generated
```

### 2. Run Converter
```bash
mvn clean compile exec:java
```

### 3. Review Output
Check `target/cucumber-generated/` for generated files

### 4. Copy Files
```bash
# Copy feature files
cp -r target/cucumber-generated/features/* src/test/resources/features/

# Copy step definitions
cp -r target/cucumber-generated/stepdefinitions/* src/test/java/com/automation/stepdefinitions/
```

### 5. Run Tests
```bash
mvn test
```

## 📋 Command Reference

### Run Converter
```bash
# Using Maven (Recommended)
mvn compile exec:java

# Using Java directly
java -cp target/classes com.automation.converter.ConversionScript

# With config file
java -cp target/classes com.automation.converter.ConversionScript config.properties

# With command line args
java -cp target/classes com.automation.converter.ConversionScript \
    <source-dir> <output-dir> <package-name>
```

### Run Tests
```bash
# All tests
mvn test

# Specific tag
mvn test -Dcucumber.filter.tags="@smoke"

# Specific feature
# Edit TestRunner.java features option
```

## 📁 Directory Structure

### Before (TestNG)
```
src/test/java/com/yourcompany/tests/
├── LoginTest.java
├── HomePageTest.java
└── DashboardTest.java
```

### After (Cucumber)
```
src/test/
├── java/com/automation/stepdefinitions/
│   ├── LoginStepDefinitions.java
│   ├── HomePageStepDefinitions.java
│   └── Hooks.java
└── resources/features/
    ├── Login.feature
    ├── HomePage.feature
    └── Dashboard.feature
```

## 🔄 Conversion Mapping

| TestNG | Cucumber |
|--------|----------|
| `@Test` | `Scenario:` |
| `@BeforeMethod` | `@Before` hook |
| `@AfterMethod` | `@After` hook |
| `groups = {"smoke"}` | `@smoke` tag |
| `description = "..."` | Scenario description |
| `Assert.assertTrue()` | `Assert.assertTrue()` (JUnit) |
| Test method | Step definitions |

## 📝 Example Conversion

### TestNG Test
```java
@Test(description = "Login test", groups = {"smoke"})
public void testLogin() {
    LoginPage loginPage = new LoginPage();
    loginPage.login("user", "pass");
    Assert.assertTrue(new HomePage().isUserLoggedIn());
}
```

### Generated Feature File
```gherkin
@smoke
Scenario: Login test
  Given I am on the login page
  When I login with username "user" and password "pass"
  Then I should see the expected result
```

### Generated Step Definitions
```java
@Given("I am on the login page")
public void i_am_on_the_login_page() {
    ExtentReportManager.logInfo("Navigating to login page");
    loginPage.navigateTo("https://example.com/login");
}

@When("I login with username {string} and password {string}")
public void i_login_with_username_and_password(String username, String password) {
    ExtentReportManager.logInfo("Logging in with username: " + username);
    loginPage.login(username, password);
}

@Then("I should see the expected result")
public void i_should_see_the_expected_result() {
    Assert.assertTrue(homePage.isUserLoggedIn());
    ExtentReportManager.logPass("Assertion passed");
}
```

## ⚙️ Configuration Options

### converter-config.properties
```properties
# Required
testng.source.directory=src/test/java/com/yourcompany/tests
cucumber.output.directory=target/cucumber-generated
cucumber.package.name=com.automation.stepdefinitions

# Optional
feature.output.directory=target/cucumber-generated/features
stepdef.output.directory=target/cucumber-generated/stepdefinitions
```

## 🎯 Common Tasks

### Convert Single Test Class
1. Place test class in source directory
2. Run converter
3. Review generated files
4. Copy to project

### Convert Multiple Test Classes
1. Place all test classes in source directory
2. Run converter once
3. All classes converted together
4. Review and copy all files

### Update Existing Conversion
1. Make changes to TestNG tests
2. Run converter again
3. Review changes
4. Update existing Cucumber files

## 🔍 Troubleshooting Quick Fixes

| Problem | Solution |
|---------|----------|
| No tests found | Check source directory path |
| Compilation errors | Verify package names and imports |
| Generic steps | Refine manually (expected) |
| Missing page objects | Update imports in step definitions |
| Reports not generated | Check Extent Reports configuration |

## 📊 Output Locations

- **Feature files**: `target/cucumber-generated/features/`
- **Step definitions**: `target/cucumber-generated/stepdefinitions/`
- **Extent Reports**: `test-output/ExtentReports/`
- **Cucumber Reports**: `target/cucumber-reports/`

## ✅ Post-Conversion Checklist

- [ ] Generated files reviewed
- [ ] Feature files refined
- [ ] Step definitions customized
- [ ] Page objects verified
- [ ] Tests run successfully
- [ ] Reports generated
- [ ] Code committed to version control

## 📚 Full Documentation

- **HOW_TO_CONVERT_GUIDE.md** - Complete step-by-step guide
- **CONVERSION_TOOL_README.md** - Tool documentation
- **QUICK_START.md** - Quick start guide
- **COMPLETE_FRAMEWORK_GUIDE.md** - Framework overview

---

**Need help? Check the full guide: HOW_TO_CONVERT_GUIDE.md**

