# How to Convert TestNG Framework to Cucumber - Step by Step Guide

## 📋 Overview

This guide will walk you through converting your existing Selenium Java TestNG Page Object Model framework to Cucumber BDD format using the automated conversion tool.

## 🎯 Prerequisites

1. **Java 8** installed and configured
2. **Maven** installed and configured
3. **Your existing TestNG test classes** ready to convert
4. **Project structure** set up

## 📁 Step 1: Prepare Your TestNG Tests

### Organize Your TestNG Tests

Ensure your TestNG test classes are in a directory structure like:

```
src/test/java/
└── com/
    └── yourcompany/
        └── tests/
            ├── LoginTest.java
            ├── HomePageTest.java
            └── DashboardTest.java
```

### Example TestNG Test Structure

Your TestNG tests should follow this pattern:

```java
package com.yourcompany.tests;

import org.testng.annotations.*;
import com.yourcompany.pages.LoginPage;
import com.yourcompany.pages.HomePage;
import org.testng.Assert;

public class LoginTest {
    
    @BeforeMethod
    public void setUp() {
        // Setup code (e.g., DriverManager.initializeDriver())
    }
    
    @Test(description = "Successful login with valid credentials", groups = {"smoke"})
    public void testLoginWithValidCredentials() {
        LoginPage loginPage = new LoginPage();
        loginPage.navigateTo("https://example.com/login");
        loginPage.login("username", "password");
        HomePage homePage = new HomePage();
        Assert.assertTrue(homePage.isUserLoggedIn());
    }
    
    @AfterMethod
    public void tearDown() {
        // Teardown code (e.g., DriverManager.quitDriver())
    }
}
```

## ⚙️ Step 2: Configure the Converter

### Edit Configuration File

Open `src/main/resources/converter-config.properties` and update it:

```properties
# Source directory containing your TestNG test classes
testng.source.directory=src/test/java/com/yourcompany/tests

# Output directory for generated Cucumber files
cucumber.output.directory=target/cucumber-generated

# Package name for generated step definitions
cucumber.package.name=com.automation.stepdefinitions

# Feature files output directory
feature.output.directory=target/cucumber-generated/features

# Step definitions output directory
stepdef.output.directory=target/cucumber-generated/stepdefinitions
```

**Important**: Update `testng.source.directory` to point to your actual TestNG test directory.

## 🚀 Step 3: Run the Conversion Tool

### Option A: Using Maven (Recommended)

```bash
# Navigate to project root
cd C:\Users\LENOVO\Downloads\TestNG

# Compile the project
mvn clean compile

# Run the converter
mvn exec:java
```

### Option B: Using Java Directly

```bash
# Compile
mvn clean compile

# Run with default config
java -cp target/classes com.automation.converter.ConversionScript

# OR run with custom config file
java -cp target/classes com.automation.converter.ConversionScript src/main/resources/converter-config.properties

# OR run with command line arguments
java -cp target/classes com.automation.converter.ConversionScript \
    src/test/java/com/yourcompany/tests \
    target/cucumber-generated \
    com.automation.stepdefinitions
```

### Option C: Using Command Line Arguments

```bash
java -cp target/classes com.automation.converter.TestNGToCucumberConverter \
    <testng-source-dir> \
    <cucumber-output-dir> \
    [package-name]
```

**Example**:
```bash
java -cp target/classes com.automation.converter.TestNGToCucumberConverter \
    src/test/java/com/yourcompany/tests \
    target/cucumber-generated \
    com.automation.stepdefinitions
```

## 📊 Step 4: Review Generated Files

After running the converter, check the output directory:

```
target/cucumber-generated/
├── features/
│   ├── Login.feature
│   ├── HomePage.feature
│   └── Dashboard.feature
└── stepdefinitions/
    ├── LoginStepDefinitions.java
    ├── HomePageStepDefinitions.java
    ├── DashboardStepDefinitions.java
    └── Hooks.java
```

### Example Generated Feature File

```gherkin
@login
Feature: Login
  As a user
  I want to test login functionality
  So that I can verify the application works correctly

  Background:
    Given the test environment is set up

  @smoke
  Scenario: Successful login with valid credentials
    Given I am on the login page
    When I login with username "username" and password "password"
    Then I should see the expected result
```

### Example Generated Step Definitions

```java
package com.automation.stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import com.automation.pages.LoginPage;
import com.automation.pages.HomePage;
import org.junit.Assert;
import com.automation.utils.ExtentReportManager;

public class LoginStepDefinitions {
    private LoginPage loginPage;
    private HomePage homePage;

    public LoginStepDefinitions() {
        this.loginPage = new LoginPage();
        this.homePage = new HomePage();
    }

    @Given("I am on the login page")
    public void i_am_on_the_login_page() {
        ExtentReportManager.logInfo("Navigating to login page");
        loginPage.navigateTo("https://example.com/login");
    }

    @When("I login with username {string} and password {string}")
    public void i_login_with_username_and_password(String username, String password) {
        ExtentReportManager.logInfo("Logging in with username: " + username);
        loginPage.login(username, password);
    }

    @Then("I should see the expected result")
    public void i_should_see_the_expected_result() {
        ExtentReportManager.logInfo("Verifying expected result");
        Assert.assertTrue(homePage.isUserLoggedIn());
        ExtentReportManager.logPass("Assertion passed");
    }
}
```

## 📝 Step 5: Copy Generated Files to Your Project

### Copy Feature Files

```bash
# Windows
xcopy /E /I target\cucumber-generated\features src\test\resources\features

# Linux/Mac
cp -r target/cucumber-generated/features/* src/test/resources/features/
```

### Copy Step Definitions

```bash
# Windows
xcopy /E /I target\cucumber-generated\stepdefinitions src\test\java\com\automation\stepdefinitions

# Linux/Mac
cp -r target/cucumber-generated/stepdefinitions/* src/test/java/com/automation/stepdefinitions/
```

**OR manually copy**:
- Feature files → `src/test/resources/features/`
- Step definitions → `src/test/java/com/automation/stepdefinitions/`

## 🔧 Step 6: Customize Generated Code

### Refine Feature Files

1. **Update scenario descriptions** - Make them more descriptive
2. **Add data tables** - For complex test data
3. **Add scenario outlines** - For data-driven tests
4. **Improve step descriptions** - Make them more readable

**Example - Before**:
```gherkin
Scenario: Login test
  Given I am on the login page
  When I login with username "user" and password "pass"
  Then I should see the expected result
```

**Example - After**:
```gherkin
Scenario: User can successfully login with valid credentials
  Given I am on the login page
  When I enter username "testuser" and password "testpass123"
  And I click on the login button
  Then I should be redirected to the home page
  And I should see the welcome message
```

### Refine Step Definitions

1. **Add parameterization** - Use {string}, {int}, etc.
2. **Improve error handling** - Add try-catch blocks
3. **Add more logging** - Use ExtentReportManager
4. **Update assertions** - Make them more specific

**Example - Enhanced Step Definition**:
```java
@When("I enter username {string} and password {string}")
public void i_enter_username_and_password(String username, String password) {
    ExtentReportManager.logInfo("Entering username: " + username);
    loginPage.enterUsername(username);
    ExtentReportManager.logInfo("Entering password");
    loginPage.enterPassword(password);
}

@And("I click on the login button")
public void i_click_on_the_login_button() {
    ExtentReportManager.logInfo("Clicking login button");
    loginPage.clickLoginButton();
}

@Then("I should be redirected to the home page")
public void i_should_be_redirected_to_the_home_page() {
    ExtentReportManager.logInfo("Verifying redirect to home page");
    String currentUrl = homePage.getCurrentUrl();
    Assert.assertTrue("Should be on home page", currentUrl.contains("home"));
    ExtentReportManager.logPass("Successfully redirected to home page");
}
```

### Update Hooks (if needed)

The generated Hooks class includes Extent Report integration. Customize if needed:

```java
@Before
public void setUp(Scenario scenario) {
    // Add custom setup logic here
    ExtentReportManager.createTest(scenario.getName(), scenario.getUri().toString());
    DriverManager.initializeDriver();
}

@After
public void tearDown(Scenario scenario) {
    // Add custom teardown logic here
    if (scenario.isFailed()) {
        // Screenshot capture is automatic
    }
    DriverManager.quitDriver();
}
```

## 🧪 Step 7: Update Your Page Objects

Ensure your page objects are compatible:

1. **Extend BasePage** (if using the framework's BasePage)
2. **Update package names** if needed
3. **Verify imports** are correct

**Example Page Object**:
```java
package com.automation.pages;

import com.automation.utils.DriverManager;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends BasePage {
    
    @FindBy(id = "username")
    private WebElement usernameField;
    
    @FindBy(id = "password")
    private WebElement passwordField;
    
    @FindBy(id = "login-button")
    private WebElement loginButton;
    
    public void enterUsername(String username) {
        helper.sendKeys(usernameField, username);
    }
    
    public void enterPassword(String password) {
        helper.sendKeys(passwordField, password);
    }
    
    public void clickLoginButton() {
        helper.click(loginButton);
    }
    
    public void login(String username, String password) {
        enterUsername(username);
        enterPassword(password);
        clickLoginButton();
    }
}
```

## ▶️ Step 8: Run Your Cucumber Tests

### Run All Tests

```bash
mvn test
```

### Run Specific Feature

Edit `TestRunner.java`:
```java
@CucumberOptions(
    features = "src/test/resources/features/Login.feature",
    // ... other options
)
```

### Run by Tags

Edit `TestRunner.java`:
```java
@CucumberOptions(
    tags = "@smoke",
    // ... other options
)
```

Or via command line:
```bash
mvn test -Dcucumber.filter.tags="@smoke"
```

## 📊 Step 9: View Reports

### Extent Reports

After test execution, open:
```
test-output/ExtentReports/ExtentReport_YYYY-MM-DD_HH-mm-ss.html
```

### Cucumber HTML Reports

```
target/cucumber-reports/cucumber.html
```

## 🔄 Step 10: Iterate and Improve

1. **Run tests** and identify failures
2. **Fix step definitions** - Update logic as needed
3. **Refine feature files** - Improve descriptions
4. **Add more scenarios** - Convert remaining TestNG tests
5. **Optimize** - Remove duplicate steps, create reusable steps

## 💡 Tips and Best Practices

### 1. Convert Incrementally

Don't convert all tests at once. Start with:
- One test class
- Review the output
- Understand the conversion
- Then convert more

### 2. Review Generated Code

Always review and refine:
- Feature file scenarios
- Step definition logic
- Assertions
- Error handling

### 3. Create Reusable Steps

Identify common steps and create reusable step definitions:

```java
@Given("I navigate to {string}")
public void i_navigate_to(String url) {
    ExtentReportManager.logInfo("Navigating to: " + url);
    driver.get(url);
}
```

### 4. Use Data Tables

For complex test data:

```gherkin
Scenario: Login with multiple users
  Given I am on the login page
  When I login with the following credentials:
    | username | password |
    | user1    | pass1    |
    | user2    | pass2    |
  Then I should see the home page
```

### 5. Use Scenario Outlines

For data-driven tests:

```gherkin
Scenario Outline: Login with different credentials
  Given I am on the login page
  When I login with username "<username>" and password "<password>"
  Then I should see "<expected_result>"

  Examples:
    | username | password | expected_result |
    | valid    | valid    | home page       |
    | invalid  | invalid  | error message   |
```

## 🐛 Troubleshooting

### No Test Classes Found

**Problem**: Converter doesn't find test classes

**Solution**:
- Check the source directory path in `converter-config.properties`
- Ensure files end with `Test.java` or `Tests.java`
- Verify files contain `@Test` annotations

### Compilation Errors

**Problem**: Generated code doesn't compile

**Solution**:
- Check package names match your project
- Verify page object imports
- Ensure all dependencies are in `pom.xml`
- Update imports if needed

### Generic Step Definitions

**Problem**: Generated steps are too generic

**Solution**:
- This is expected - refine them manually
- Add more specific logic
- Improve step descriptions
- Add parameterization

### Missing Page Objects

**Problem**: Page objects not found

**Solution**:
- Update package names in step definitions
- Ensure page objects are in the correct package
- Update imports

## 📚 Additional Resources

- **CONVERSION_TOOL_README.md** - Detailed conversion tool documentation
- **QUICK_START.md** - Quick start guide
- **COMPLETE_FRAMEWORK_GUIDE.md** - Complete framework overview
- **EXTENT_REPORT_GUIDE.md** - Extent Reports guide

## ✅ Checklist

- [ ] TestNG tests organized in directory
- [ ] Configuration file updated
- [ ] Converter executed successfully
- [ ] Generated files reviewed
- [ ] Files copied to project
- [ ] Code customized and refined
- [ ] Page objects updated
- [ ] Tests run successfully
- [ ] Reports generated
- [ ] Framework ready for use

## 🎉 Success!

Once you complete these steps, you'll have:
- ✅ Converted TestNG tests to Cucumber format
- ✅ Feature files in Gherkin syntax
- ✅ Step definitions with Extent Report logging
- ✅ Hooks with setup/teardown
- ✅ Working Cucumber framework
- ✅ Comprehensive test reports

---

**Happy Converting! 🚀**

