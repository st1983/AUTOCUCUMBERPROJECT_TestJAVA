# Quick Start Guide - TestNG to Cucumber Conversion Tool

## Overview

This tool automatically converts your existing Selenium Java TestNG Page Object Model tests to Cucumber BDD format.

## Quick Start

### Step 1: Prepare Your TestNG Tests

Ensure your TestNG test classes are in a directory (e.g., `src/test/java/com/automation/tests`).

Example test structure:
```java
@BeforeMethod
public void setUp() { ... }

@Test(description = "Test description", groups = {"smoke"})
public void testMethod() { ... }

@AfterMethod
public void tearDown() { ... }
```

### Step 2: Configure the Converter

Edit `src/main/resources/converter-config.properties`:
```properties
testng.source.directory=src/test/java/com/automation/tests
cucumber.output.directory=target/cucumber-generated
cucumber.package.name=com.automation.stepdefinitions
```

### Step 3: Run the Converter

**Option A: Using Maven**
```bash
mvn compile exec:java
```

**Option B: Using Java directly**
```bash
# Compile
mvn compile

# Run
java -cp target/classes com.automation.converter.ConversionScript
```

**Option C: With command line arguments**
```bash
java -cp target/classes com.automation.converter.ConversionScript \
    src/test/java/com/automation/tests \
    target/cucumber-generated \
    com.automation.stepdefinitions
```

### Step 4: Review Generated Files

The converter generates:
- **Feature files**: `target/cucumber-generated/features/*.feature`
- **Step definitions**: `target/cucumber-generated/stepdefinitions/*StepDefinitions.java`
- **Hooks**: `target/cucumber-generated/stepdefinitions/Hooks.java`

### Step 5: Customize Generated Code

1. **Review feature files** - Update scenario descriptions and steps
2. **Refine step definitions** - Add parameterization and improve logic
3. **Update hooks** - Customize setup/teardown as needed
4. **Move files** - Copy generated files to your test source directory

### Step 6: Run Cucumber Tests

```bash
mvn test
```

## Example Conversion

### Before (TestNG):
```java
@Test(description = "Login test", groups = {"smoke"})
public void testLogin() {
    LoginPage loginPage = new LoginPage();
    loginPage.login("user", "pass");
    Assert.assertTrue(new HomePage().isUserLoggedIn());
}
```

### After (Cucumber):

**Feature File:**
```gherkin
@smoke
Scenario: Login test
  Given I am on the login page
  When I login with username "user" and password "pass"
  Then I should see the expected result
```

**Step Definitions:**
```java
@Given("I am on the login page")
public void i_am_on_the_login_page() {
    loginPage.navigateTo("https://example.com/login");
}

@When("I login with username {string} and password {string}")
public void i_login_with_username_and_password(String username, String password) {
    loginPage.login(username, password);
}

@Then("I should see the expected result")
public void i_should_see_the_expected_result() {
    Assert.assertTrue(homePage.isUserLoggedIn());
}
```

## Tips

1. **Start Small**: Convert one test class first to understand the output
2. **Review Output**: Always review and refine generated code
3. **Incremental**: Convert tests incrementally, not all at once
4. **Test After Conversion**: Run tests after each conversion to ensure they work
5. **Customize**: The tool provides a starting point - customize as needed

## Troubleshooting

**No test classes found?**
- Check the source directory path
- Ensure files end with `Test.java` or `Tests.java`
- Verify files contain `@Test` annotations

**Compilation errors?**
- Check package names match your project
- Verify page object imports
- Ensure all dependencies are in `pom.xml`

**Generated steps too generic?**
- This is expected - refine them manually
- Add more specific pattern matching
- Enhance method body analysis

## Next Steps

1. Read `CONVERSION_TOOL_README.md` for detailed documentation
2. Review generated files and customize
3. Integrate into your CI/CD pipeline
4. Share feedback for improvements

