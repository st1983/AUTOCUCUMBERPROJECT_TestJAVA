# Jira and Azure DevOps to Cucumber Conversion Guide

## 🎯 Overview

This framework includes tools to fetch test cases from **Jira** and **Azure DevOps (ADO)** and automatically convert them to Cucumber feature files.

## 📋 Features

✅ **Jira Integration** - Fetch test cases from Jira projects, filters, or JQL queries  
✅ **Azure DevOps Integration** - Fetch test cases from test plans, test suites, or work items  
✅ **Automatic Conversion** - Convert test cases to Gherkin feature files  
✅ **Tag Support** - Preserve labels/tags from test management tools  
✅ **Step Detection** - Automatically detect and convert test steps  

## 🔧 Prerequisites

### For Jira

1. **Jira URL** - Your Jira instance URL (e.g., `https://yourcompany.atlassian.net`)
2. **Username** - Your Jira username/email
3. **API Token** - Generate from: Jira → Account Settings → Security → API Tokens

### For Azure DevOps

1. **Organization** - Your Azure DevOps organization name
2. **Project** - Your project name
3. **Personal Access Token (PAT)** - Generate from: Azure DevOps → User Settings → Personal Access Tokens

## 🚀 Jira Conversion

### Step 1: Get Jira API Token

1. Log in to Jira
2. Go to **Account Settings** → **Security**
3. Click **Create API Token**
4. Copy the token (you'll need it for configuration)

### Step 2: Configure

Edit `src/main/resources/jira-converter-config.properties`:

```properties
# Jira Connection
jira.url=https://yourcompany.atlassian.net
jira.username=your-email@company.com
jira.api.token=your-api-token-here

# Conversion Type: project, filter, jql, issue
conversion.type=project

# For project conversion
jira.project.key=PROJ

# Output
output.directory=target/jira-features
```

### Step 3: Run Conversion

**Option A: Using Config File**

```bash
mvn compile
java -cp target/classes com.automation.converter.JiraCucumberConverterRunner \
    https://yourcompany.atlassian.net \
    your-email@company.com \
    your-api-token \
    target/jira-features \
    jira-converter-config.properties
```

**Option B: Command Line**

```bash
# Convert from project
java -cp target/classes com.automation.converter.JiraCucumberConverterRunner \
    https://yourcompany.atlassian.net \
    your-email@company.com \
    your-api-token \
    target/jira-features \
    project PROJ

# Convert from filter
java -cp target/classes com.automation.converter.JiraCucumberConverterRunner \
    https://yourcompany.atlassian.net \
    your-email@company.com \
    your-api-token \
    target/jira-features \
    filter 12345

# Convert using JQL
java -cp target/classes com.automation.converter.JiraCucumberConverterRunner \
    https://yourcompany.atlassian.net \
    your-email@company.com \
    your-api-token \
    target/jira-features \
    jql "project = PROJ AND type = Test" my_feature

# Convert single test case
java -cp target/classes com.automation.converter.JiraCucumberConverterRunner \
    https://yourcompany.atlassian.net \
    your-email@company.com \
    your-api-token \
    target/jira-features \
    issue PROJ-123
```

### Step 4: Review Generated Files

Check `target/jira-features/` for generated `.feature` files.

## 🚀 Azure DevOps Conversion

### Step 1: Get Personal Access Token (PAT)

1. Log in to Azure DevOps
2. Go to **User Settings** → **Personal Access Tokens**
3. Click **New Token**
4. Set scope: **Test Management (Read)**
5. Copy the token

### Step 2: Configure

Edit `src/main/resources/ado-converter-config.properties`:

```properties
# Azure DevOps Connection
ado.organization=your-organization
ado.project=your-project
ado.personal.access.token=your-pat-here

# Conversion Type: testplan, testsuite, testcase
conversion.type=testplan

# For test plan conversion
ado.testplan.id=12345

# Output
output.directory=target/ado-features
```

### Step 3: Run Conversion

**Option A: Using Config File**

```bash
mvn compile
java -cp target/classes com.automation.converter.AzureDevOpsCucumberConverterRunner \
    your-organization \
    your-project \
    your-pat \
    target/ado-features \
    ado-converter-config.properties
```

**Option B: Command Line**

```bash
# Convert from test plan
java -cp target/classes com.automation.converter.AzureDevOpsCucumberConverterRunner \
    your-organization \
    your-project \
    your-pat \
    target/ado-features \
    testplan 12345 my_feature

# Convert from test suite
java -cp target/classes com.automation.converter.AzureDevOpsCucumberConverterRunner \
    your-organization \
    your-project \
    your-pat \
    target/ado-features \
    testsuite 12345 67890 my_feature

# Convert single test case
java -cp target/classes com.automation.converter.AzureDevOpsCucumberConverterRunner \
    your-organization \
    your-project \
    your-pat \
    target/ado-features \
    testcase 123456
```

### Step 4: Review Generated Files

Check `target/ado-features/` for generated `.feature` files.

## 📝 Example Output

### Jira Test Case Input

**Jira Test Case:**
- Key: `PROJ-123`
- Summary: `Login with valid credentials`
- Description: `Verify user can login with valid username and password`
- Labels: `smoke`, `login`
- Steps:
  1. Navigate to login page
  2. Enter username
  3. Enter password
  4. Click login button
  5. Verify home page is displayed

### Generated Feature File

```gherkin
Feature: Login Tests
  As a tester
  I want to execute test cases from Jira
  So that I can verify the application functionality

  @smoke @login
  Scenario: Login with valid credentials
    # Jira Test Case: PROJ-123
    Given Navigate to login page
    When Enter username
    And Enter password
    And Click login button
    Then Verify home page is displayed
```

## 🔍 Conversion Details

### What Gets Converted

| Source | Cucumber Output |
|--------|----------------|
| Test Case Title | Scenario name |
| Test Case Description | Feature/Scenario description |
| Test Steps | Gherkin steps (Given/When/Then) |
| Labels/Tags | Cucumber tags |
| Priority | Tag (optional) |
| Test Case ID | Comment in feature file |

### Step Detection

The converter automatically detects step types:

- **Given** - Steps with keywords: navigate, go to, open, visit, access
- **When** - Steps with keywords: click, select, enter, type, input, fill, submit, login, logout
- **Then** - Steps with keywords: verify, check, validate, assert, confirm, should, expect

### Manual Refinement

After conversion, you may need to:

1. **Refine step descriptions** - Make them more readable
2. **Add parameters** - Use `{string}`, `{int}`, etc.
3. **Improve scenario names** - Make them more descriptive
4. **Add data tables** - For complex test data
5. **Create step definitions** - Implement the steps in Java

## 🛠️ Advanced Usage

### Custom JQL Queries (Jira)

```bash
java -cp target/classes com.automation.converter.JiraCucumberConverterRunner \
    https://yourcompany.atlassian.net \
    user@email.com \
    token \
    target/features \
    jql "project = PROJ AND type = Test AND labels = smoke AND status != Closed" \
    smoke_tests
```

### Multiple Test Plans (Azure DevOps)

Create a script to convert multiple test plans:

```bash
#!/bin/bash
for plan_id in 12345 67890 11111; do
    java -cp target/classes com.automation.converter.AzureDevOpsCucumberConverterRunner \
        org project pat target/features testplan $plan_id plan_$plan_id
done
```

## 🔐 Security Best Practices

1. **Never commit API tokens** - Use environment variables or secure config files
2. **Use environment variables**:
   ```bash
   export JIRA_API_TOKEN=your-token
   export ADO_PAT=your-pat
   ```
3. **Add to .gitignore**:
   ```
   *-config.properties
   *.token
   *.pat
   ```

## 🐛 Troubleshooting

### Jira Issues

**Problem**: Authentication failed  
**Solution**: 
- Verify API token is correct
- Check username/email is correct
- Ensure token has read permissions

**Problem**: No test cases found  
**Solution**:
- Verify project key is correct
- Check JQL query syntax
- Ensure test cases exist in Jira

### Azure DevOps Issues

**Problem**: Authentication failed  
**Solution**:
- Verify PAT is correct
- Check organization and project names
- Ensure PAT has Test Management (Read) scope

**Problem**: Test plan not found  
**Solution**:
- Verify test plan ID is correct
- Check organization and project names
- Ensure you have access to the test plan

## 📚 Integration with Existing Framework

After converting from Jira/ADO:

1. **Copy feature files** to `src/test/resources/features/`
2. **Create step definitions** (or use existing ones)
3. **Run tests**: `mvn test`
4. **View reports**: Check `test-output/ExtentReports/`

## ✅ Checklist

- [ ] API token/PAT generated
- [ ] Configuration file updated
- [ ] Test cases fetched successfully
- [ ] Feature files generated
- [ ] Feature files reviewed and refined
- [ ] Step definitions created
- [ ] Tests run successfully

## 🎉 Success!

You now have:
- ✅ Test cases from Jira/ADO converted to Cucumber
- ✅ Feature files ready for automation
- ✅ Tags and metadata preserved
- ✅ Integration with your test framework

---

**Happy Converting! 🚀**

