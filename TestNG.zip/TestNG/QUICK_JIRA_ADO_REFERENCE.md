# Quick Reference - Jira & Azure DevOps to Cucumber

## 🚀 Quick Start

### Jira Conversion

```bash
# 1. Get API token from Jira
# 2. Configure jira-converter-config.properties
# 3. Run:
mvn compile
java -cp target/classes com.automation.converter.JiraCucumberConverterRunner \
    https://yourcompany.atlassian.net \
    user@email.com \
    api-token \
    target/jira-features \
    project PROJ
```

### Azure DevOps Conversion

```bash
# 1. Get PAT from Azure DevOps
# 2. Configure ado-converter-config.properties
# 3. Run:
mvn compile
java -cp target/classes com.automation.converter.AzureDevOpsCucumberConverterRunner \
    organization \
    project \
    pat \
    target/ado-features \
    testplan 12345
```

## 📋 Conversion Types

### Jira

| Type | Command | Example |
|------|---------|---------|
| Project | `project <key>` | `project PROJ` |
| Filter | `filter <id>` | `filter 12345` |
| JQL | `jql "<query>" [name]` | `jql "project = PROJ AND type = Test"` |
| Issue | `issue <key>` | `issue PROJ-123` |

### Azure DevOps

| Type | Command | Example |
|------|---------|---------|
| Test Plan | `testplan <id> [name]` | `testplan 12345` |
| Test Suite | `testsuite <plan-id> <suite-id> [name]` | `testsuite 12345 67890` |
| Test Case | `testcase <workitem-id>` | `testcase 123456` |

## 🔑 Getting Credentials

### Jira API Token
1. Jira → Account Settings → Security
2. Create API Token
3. Copy token

### Azure DevOps PAT
1. Azure DevOps → User Settings → Personal Access Tokens
2. New Token
3. Scope: Test Management (Read)
4. Copy token

## 📁 Output

Generated feature files in:
- Jira: `target/jira-features/`
- Azure DevOps: `target/ado-features/`

## ✅ Next Steps

1. Review generated feature files
2. Refine step descriptions
3. Copy to `src/test/resources/features/`
4. Create step definitions
5. Run tests: `mvn test`

## 📚 Full Guide

See **JIRA_ADO_CONVERSION_GUIDE.md** for complete documentation.

