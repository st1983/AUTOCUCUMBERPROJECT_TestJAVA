# Cucumber Java Page Object Model Framework with Extent Reports

This is a Selenium Java framework converted from TestNG to Cucumber BDD format, maintaining the Page Object Model pattern. The framework includes **100% automated conversion tool** and **Extent Report integration** for comprehensive test reporting.

## Framework Structure

```
cucumber-pageobject-framework/
├── pom.xml
├── src/
│   ├── main/
│   │   └── java/
│   │       └── com/
│   │           └── automation/
│   │               ├── pages/
│   │               │   ├── BasePage.java
│   │               │   ├── LoginPage.java
│   │               │   └── HomePage.java
│   │               └── utils/
│   │                   ├── DriverManager.java
│   │                   ├── ConfigReader.java
│   │                   └── Helper.java
│   └── test/
│       ├── java/
│       │   └── com/
│       │       └── automation/
│       │           ├── runners/
│       │           │   └── TestRunner.java
│       │           └── stepdefinitions/
│       │               ├── Hooks.java
│       │               ├── LoginStepDefinitions.java
│       │               └── HomePageStepDefinitions.java
│       └── resources/
│           ├── features/
│           │   ├── Login.feature
│           │   └── HomePage.feature
│           └── config/
│               └── config.properties
└── README.md
```

## Key Differences from TestNG Framework

### 1. Test Structure
- **TestNG**: Test methods with `@Test` annotations
- **Cucumber**: Feature files with Gherkin syntax and step definitions

### 2. Test Execution
- **TestNG**: TestNG XML suites or test classes
- **Cucumber**: Feature files executed via TestRunner with JUnit

### 3. Setup/Teardown
- **TestNG**: `@BeforeMethod`, `@AfterMethod`, `@BeforeClass`, `@AfterClass`
- **Cucumber**: `@Before` and `@After` hooks in Hooks class

### 4. Assertions
- **TestNG**: TestNG assertions (`Assert.assertTrue()`, etc.)
- **Cucumber**: JUnit assertions (same syntax, but using JUnit)

## Migration Guide

### Converting TestNG Test Methods to Cucumber

**Before (TestNG):**
```java
@Test
public void testLoginWithValidCredentials() {
    LoginPage loginPage = new LoginPage();
    loginPage.navigateTo("https://example.com/login");
    loginPage.login("username", "password");
    HomePage homePage = new HomePage();
    Assert.assertTrue(homePage.isUserLoggedIn());
}
```

**After (Cucumber):**

**Feature File:**
```gherkin
Scenario: Successful login with valid credentials
  Given I am on the login page
  When I login with username "username" and password "password"
  Then I should be redirected to the home page
```

**Step Definition:**
```java
@Given("I am on the login page")
public void i_am_on_the_login_page() {
    loginPage.navigateTo("https://example.com/login");
}

@When("I login with username {string} and password {string}")
public void i_login_with_username_and_password(String username, String password) {
    loginPage.login(username, password);
}

@Then("I should be redirected to the home page")
public void i_should_be_redirected_to_the_home_page() {
    Assert.assertTrue("User should be logged in", homePage.isUserLoggedIn());
}
```

## Running Tests

### Run all tests:
```bash
mvn test
```

### Run specific feature:
Modify `@CucumberOptions` in `TestRunner.java`:
```java
features = "src/test/resources/features/Login.feature"
```

### Run by tags:
Modify tags in `TestRunner.java`:
```java
tags = "@smoke"
```

Or via command line:
```bash
mvn test -Dcucumber.filter.tags="@smoke"
```

## Dependencies

- **Java 8** (Compatible)
- Selenium WebDriver 3.141.59 (Java 8 compatible)
- Cucumber Java 6.10.4 (Java 8 compatible)
- WebDriverManager 4.4.3 (Java 8 compatible)
- JUnit 4.13.2
- Extent Reports 4.1.7 (Java 8 compatible)
- TestNG 7.8.0

## Configuration

Edit `src/test/resources/config/config.properties` to configure:
- Browser type (chrome, firefox, edge)
- Headless mode
- Application URLs
- Timeouts
- Test data

## Page Object Model

The framework maintains the Page Object Model pattern:
- All page classes extend `BasePage`
- Page classes use `@FindBy` annotations
- Common utilities in `Helper` class
- Driver management via `DriverManager`

## Best Practices

1. **Page Objects**: Keep all page-specific logic in page classes
2. **Step Definitions**: Keep step definitions thin, delegate to page objects
3. **Reusability**: Create reusable step definitions for common actions
4. **Tags**: Use tags to organize and filter tests (@smoke, @regression, etc.)
5. **Hooks**: Use hooks for setup/teardown, not step definitions

## Converting Your Existing TestNG Tests

### 🚀 Quick Conversion (Automated)

**Use the automated conversion tool** to convert your TestNG tests to Cucumber format:

1. **Configure**: Edit `src/main/resources/converter-config.properties`
2. **Run**: `mvn compile exec:java`
3. **Review**: Check generated files in `target/cucumber-generated/`
4. **Copy**: Move files to your test directory
5. **Test**: Run `mvn test`

**📖 See [HOW_TO_CONVERT_GUIDE.md](HOW_TO_CONVERT_GUIDE.md) for complete step-by-step instructions**

### Manual Conversion

1. **Identify test scenarios** from your TestNG test methods
2. **Write feature files** in Gherkin syntax describing the scenarios
3. **Create step definitions** that map to your existing page object methods
4. **Move setup/teardown** logic to Hooks class
5. **Update assertions** to use JUnit instead of TestNG (syntax is similar)

## Example Conversion

**TestNG Test:**
```java
public class LoginTest {
    @BeforeMethod
    public void setUp() {
        DriverManager.initializeDriver();
    }
    
    @Test
    public void testLogin() {
        LoginPage loginPage = new LoginPage();
        loginPage.login("user", "pass");
        Assert.assertTrue(new HomePage().isUserLoggedIn());
    }
    
    @AfterMethod
    public void tearDown() {
        DriverManager.quitDriver();
    }
}
```

**Cucumber Equivalent:**

**Hooks.java:**
```java
@Before
public void setUp(Scenario scenario) {
    DriverManager.initializeDriver();
}

@After
public void tearDown(Scenario scenario) {
    DriverManager.quitDriver();
}
```

**Login.feature:**
```gherkin
Scenario: User login
  Given I am on the login page
  When I login with username "user" and password "pass"
  Then I should be redirected to the home page
```

**LoginStepDefinitions.java:**
```java
@Given("I am on the login page")
public void i_am_on_the_login_page() {
    loginPage.navigateTo("https://example.com/login");
}

@When("I login with username {string} and password {string}")
public void i_login_with_username_and_password(String username, String password) {
    loginPage.login(username, password);
}

@Then("I should be redirected to the home page")
public void i_should_be_redirected_to_the_home_page() {
    Assert.assertTrue(homePage.isUserLoggedIn());
}
```

## Reports

Cucumber generates HTML reports in `target/cucumber-reports/cucumber.html` after test execution.

