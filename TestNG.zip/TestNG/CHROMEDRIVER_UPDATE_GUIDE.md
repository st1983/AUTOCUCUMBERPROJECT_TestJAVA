# ChromeDriver Update Guide

## ✅ ChromeDriver is Automatically Managed

The framework uses **WebDriverManager** which **automatically downloads and manages the latest compatible ChromeDriver** for your Chrome browser version.

## 🔄 How It Works

### Automatic ChromeDriver Management

When you run tests, WebDriverManager:

1. **Detects your Chrome browser version** automatically
2. **Downloads the matching ChromeDriver** if not already cached
3. **Sets up the driver path** automatically
4. **Uses the latest compatible version** available

### Current Configuration

**WebDriverManager Version**: `5.0.1` (Java 8 compatible)

**Location**: `src/main/java/com/automation/utils/DriverManager.java`

```java
case "chrome":
    // WebDriverManager automatically downloads and sets up the latest compatible ChromeDriver
    WebDriverManager.chromedriver().setup();
    ChromeOptions chromeOptions = new ChromeOptions();
    // ... options configuration
    driver.set(new ChromeDriver(chromeOptions));
    break;
```

## 🚀 No Manual Update Needed!

**You don't need to manually update ChromeDriver** - WebDriverManager handles it automatically!

### First Run

On the first run, WebDriverManager will:
- Detect your Chrome version
- Download the matching ChromeDriver
- Cache it in `~/.m2/repository/webdriver/` (or similar)
- Use it for all subsequent runs

### Subsequent Runs

- WebDriverManager checks if the cached driver matches your Chrome version
- If Chrome is updated, it automatically downloads the new matching driver
- No manual intervention needed!

## 📋 Manual Override (If Needed)

If you need to force a specific ChromeDriver version:

```java
// In DriverManager.java, you can specify a version:
WebDriverManager.chromedriver().driverVersion("120.0.6099.109").setup();
```

Or use a specific browser version:

```java
WebDriverManager.chromedriver().browserVersion("120").setup();
```

## 🔍 Verify ChromeDriver Version

### Check Your Chrome Version

1. Open Chrome
2. Go to `chrome://settings/help`
3. Note your Chrome version (e.g., 120.0.6099.109)

### Check Downloaded ChromeDriver

WebDriverManager downloads drivers to:
- **Windows**: `C:\Users\<username>\.m2\repository\webdriver\chromedriver\`
- **Linux/Mac**: `~/.m2/repository/webdriver/chromedriver/`

### View in Logs

When you run tests, WebDriverManager logs the driver version:

```
INFO io.github.bonigarcia.wdm.WebDriverManager - Using chromedriver 120.0.6099.109 (resolved driver for Chrome 120)
```

## 🔧 Troubleshooting

### ChromeDriver Not Found

**Problem**: ChromeDriver not downloading

**Solution**:
1. Check internet connection (WebDriverManager needs to download)
2. Clear WebDriverManager cache:
   ```bash
   # Windows
   rmdir /s C:\Users\<username>\.m2\repository\webdriver
   
   # Linux/Mac
   rm -rf ~/.m2/repository/webdriver
   ```
3. Run tests again - WebDriverManager will re-download

### Version Mismatch

**Problem**: ChromeDriver version doesn't match Chrome

**Solution**: 
- WebDriverManager should handle this automatically
- If issues persist, update Chrome browser to latest version
- Or manually specify version (see Manual Override above)

### Slow First Run

**Problem**: First test run is slow

**Solution**: 
- This is normal - WebDriverManager is downloading ChromeDriver
- Subsequent runs will be faster (uses cached driver)

## 📊 WebDriverManager Versions

| Version | Java Requirement | ChromeDriver Support |
|---------|------------------|---------------------|
| 4.6.2 | Java 8+ | ✅ Latest |
| 5.x | Java 11+ | ✅ Latest |

**Current**: Using 4.6.2 (Java 8 compatible)

## 🎯 Best Practices

1. **Keep Chrome Updated** - WebDriverManager will automatically use matching driver
2. **Don't Manually Download ChromeDriver** - Let WebDriverManager handle it
3. **Clear Cache if Issues** - If driver issues occur, clear WebDriverManager cache
4. **Check Logs** - WebDriverManager logs show which driver version is being used

## ✅ Summary

- ✅ **ChromeDriver is automatically managed**
- ✅ **No manual updates needed**
- ✅ **Always uses latest compatible version**
- ✅ **Works with your Chrome browser version**

**Just run your tests - WebDriverManager handles everything! 🚀**

